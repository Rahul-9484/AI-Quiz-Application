#!/usr/bin/env python3
"""
Script to add simple, easy-to-understand sample questions to the database
Run: python add_questions.py
"""

import sqlite3
import sys
from datetime import datetime

DATABASE = "database.db"

# Ensure Windows consoles that default to cp1252 don't crash on emoji output.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# Simple questions with clear language - NO CONFUSING SYMBOLS!
QUESTIONS = [
    # Python Questions - SIMPLE
    {
        "question": "What will this code print? print(8)?",
        "option1": "6",
        "option2": "8",
        "option3": "9",
        "option4": "12",
        "correct_answer": "8",
        "difficulty": "easy",
    },
    {
        "question": "In Python, which word is used to start a function?",
        "option1": "function",
        "option2": "def",
        "option3": "func",
        "option4": "make",
        "correct_answer": "def",
        "difficulty": "easy",
    },
    {
        "question": "What is a list in Python?",
        "option1": "A single number",
        "option2": "A collection of items in order",
        "option3": "A single word",
        "option4": "A type of error",
        "correct_answer": "A collection of items in order",
        "difficulty": "easy",
    },
    {
        "question": "How do you add an item to the end of a list in Python?",
        "option1": "add()",
        "option2": "insert()",
        "option3": "append()",
        "option4": "push()",
        "correct_answer": "append()",
        "difficulty": "medium",
    },
    {
        "question": "What does len() do in Python?",
        "option1": "Makes text longer",
        "option2": "Counts items in a list",
        "option3": "Deletes items",
        "option4": "Creates a function",
        "correct_answer": "Counts items in a list",
        "difficulty": "easy",
    },
    # General Knowledge - SIMPLE
    {
        "question": "What is the capital of France?",
        "option1": "London",
        "option2": "Paris",
        "option3": "Berlin",
        "option4": "Madrid",
        "correct_answer": "Paris",
        "difficulty": "easy",
    },
    {
        "question": "Which planet is known as the Red Planet?",
        "option1": "Venus",
        "option2": "Mars",
        "option3": "Jupiter",
        "option4": "Saturn",
        "correct_answer": "Mars",
        "difficulty": "easy",
    },
    {
        "question": "Who painted the Mona Lisa?",
        "option1": "Van Gogh",
        "option2": "Picasso",
        "option3": "Leonardo da Vinci",
        "option4": "Michelangelo",
        "correct_answer": "Leonardo da Vinci",
        "difficulty": "medium",
    },
    {
        "question": "In which year did World War II end?",
        "option1": "1943",
        "option2": "1944",
        "option3": "1945",
        "option4": "1946",
        "correct_answer": "1945",
        "difficulty": "medium",
    },
    {
        "question": "What is the largest ocean in the world?",
        "option1": "Atlantic Ocean",
        "option2": "Indian Ocean",
        "option3": "Arctic Ocean",
        "option4": "Pacific Ocean",
        "correct_answer": "Pacific Ocean",
        "difficulty": "easy",
    },
    # Science - SIMPLE
    {
        "question": "Which gas do plants need to make food?",
        "option1": "Oxygen",
        "option2": "Carbon Dioxide",
        "option3": "Nitrogen",
        "option4": "Hydrogen",
        "correct_answer": "Carbon Dioxide",
        "difficulty": "easy",
    },
    {
        "question": "What is the powerhouse of the cell?",
        "option1": "Nucleus",
        "option2": "Ribosome",
        "option3": "Mitochondria",
        "option4": "Chloroplast",
        "correct_answer": "Mitochondria",
        "difficulty": "medium",
    },
    {
        "question": "How many bones are in an adult human body?",
        "option1": "186",
        "option2": "206",
        "option3": "226",
        "option4": "246",
        "correct_answer": "206",
        "difficulty": "medium",
    },
    {
        "question": "What does H2O represent?",
        "option1": "Salt",
        "option2": "Water",
        "option3": "Oxygen",
        "option4": "Hydrogen",
        "correct_answer": "Water",
        "difficulty": "easy",
    },
    {
        "question": "What is the speed of light?",
        "option1": "100,000 km per second",
        "option2": "200,000 km per second",
        "option3": "300,000 km per second",
        "option4": "400,000 km per second",
        "correct_answer": "300,000 km per second",
        "difficulty": "hard",
    },
    # Mathematics - SIMPLE
    {
        "question": "What is 10 plus 5?",
        "option1": "12",
        "option2": "14",
        "option3": "15",
        "option4": "16",
        "correct_answer": "15",
        "difficulty": "easy",
    },
    {
        "question": "What is 20 divided by 4?",
        "option1": "4",
        "option2": "5",
        "option3": "6",
        "option4": "7",
        "correct_answer": "5",
        "difficulty": "easy",
    },
    {
        "question": "What is 15 percent of 100?",
        "option1": "10",
        "option2": "15",
        "option3": "20",
        "option4": "25",
        "correct_answer": "15",
        "difficulty": "medium",
    },
    {
        "question": "If a rectangle has length 5 and width 3, what is its area?",
        "option1": "8",
        "option2": "15",
        "option3": "10",
        "option4": "25",
        "correct_answer": "15",
        "difficulty": "medium",
    },
    {
        "question": "What is the square root of 144?",
        "option1": "10",
        "option2": "11",
        "option3": "12",
        "option4": "13",
        "correct_answer": "12",
        "difficulty": "easy",
    },
    # Technology - SIMPLE
    {
        "question": "What does AI stand for?",
        "option1": "Automated Intelligence",
        "option2": "Artificial Intelligence",
        "option3": "Advanced Interaction",
        "option4": "Automated Interaction",
        "correct_answer": "Artificial Intelligence",
        "difficulty": "easy",
    },
    {
        "question": "Which language is used to create web pages?",
        "option1": "Python",
        "option2": "Java",
        "option3": "HTML",
        "option4": "C++",
        "correct_answer": "HTML",
        "difficulty": "medium",
    },
    {
        "question": "What does HTTP stand for?",
        "option1": "HyperText Transfer Protocol",
        "option2": "High Transfer Text Protocol",
        "option3": "Home Text Transfer Protocol",
        "option4": "Hyper Transfer Text Protocol",
        "correct_answer": "HyperText Transfer Protocol",
        "difficulty": "hard",
    },
    # Sports - SIMPLE
    {
        "question": "How many players are on a cricket field?",
        "option1": "9",
        "option2": "10",
        "option3": "11",
        "option4": "12",
        "correct_answer": "11",
        "difficulty": "easy",
    },
    {
        "question": "In tennis, what is the name of the court?",
        "option1": "Field",
        "option2": "Court",
        "option3": "Arena",
        "option4": "Ground",
        "correct_answer": "Court",
        "difficulty": "easy",
    },
    # Geography - SIMPLE
    {
        "question": "How many continents are there?",
        "option1": "5",
        "option2": "6",
        "option3": "7",
        "option4": "8",
        "correct_answer": "7",
        "difficulty": "easy",
    },
    {
        "question": "What is the smallest country in the world?",
        "option1": "Monaco",
        "option2": "Vatican City",
        "option3": "Liechtenstein",
        "option4": "San Marino",
        "correct_answer": "Vatican City",
        "difficulty": "hard",
    },
    {
        "question": "Which is the largest continent?",
        "option1": "Africa",
        "option2": "North America",
        "option3": "Asia",
        "option4": "Europe",
        "correct_answer": "Asia",
        "difficulty": "medium",
    },
    {
        "question": "What is the capital of India?",
        "option1": "Mumbai",
        "option2": "Delhi",
        "option3": "Bangalore",
        "option4": "Kolkata",
        "correct_answer": "Delhi",
        "difficulty": "easy",
    },
    {
        "question": "Which country has the most population?",
        "option1": "China",
        "option2": "India",
        "option3": "USA",
        "option4": "Indonesia",
        "correct_answer": "India",
        "difficulty": "medium",
    },
]


def add_questions():
    """Add sample questions to database"""

    print("\n" + "=" * 70)
    print("📚 ADDING SIMPLE SAMPLE QUESTIONS TO DATABASE")
    print("=" * 70)

    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Admin user ID
        admin_id = 1

        added = 0
        skipped = 0

        for q in QUESTIONS:
            try:
                cursor.execute(
                    """
                INSERT INTO questions
                (question, option1, option2, option3, option4, correct_answer, difficulty, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        q["question"],
                        q["option1"],
                        q["option2"],
                        q["option3"],
                        q["option4"],
                        q["correct_answer"],
                        q["difficulty"],
                        admin_id,
                        datetime.now().isoformat(),
                    ),
                )
                added += 1
                print(f"  ✅ Added: {q['question'][:60]}...")

            except sqlite3.IntegrityError:
                skipped += 1
            except Exception as e:
                print(f"  ❌ Error: {str(e)}")

        conn.commit()
        conn.close()

        print("\n" + "=" * 70)
        print(f"✅ SUCCESS! Added {added} questions")
        print(f"   📊 Easy: {sum(1 for q in QUESTIONS if q['difficulty'] == 'easy')}")
        print(
            f"   📊 Medium: {sum(1 for q in QUESTIONS if q['difficulty'] == 'medium')}"
        )
        print(f"   📊 Hard: {sum(1 for q in QUESTIONS if q['difficulty'] == 'hard')}")
        print("=" * 70 + "\n")

        return True

    except Exception as e:
        print(f"\n❌ ERROR: {e}\n")
        return False


if __name__ == "__main__":
    print("\n🎓 AI QUIZ APP - ADD SIMPLE QUESTIONS")
    try:
        success = add_questions()
        if success:
            print("✨ Questions added successfully!")
            print("Now run: python app.py\n")
    except Exception as e:
        print(f"❌ Error: {e}\n")
