#!/usr/bin/env python3
"""
Migration script to add quiz types support (regular, cnacle, practice)
Run: python migrate_db.py
"""

import os
import sqlite3
import sys
from datetime import datetime

# Ensure Windows consoles that default to cp1252 don't crash on emoji output.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# Get the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(script_dir, "database.db")

print("=" * 70)
print("🔄 DATABASE MIGRATION - ADDING QUIZ TYPES SUPPORT")
print("=" * 70)

if not os.path.exists(db_path):
    print(f"\n❌ Database not found at {db_path}")
    print("Please run: python init_db.py first")
    exit(1)

try:
    print(f"\n📂 Connecting to database: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    print("✅ Connection established")
except Exception as e:
    print(f"❌ Error connecting to database: {e}")
    exit(1)

# Migration 1: Add quiz_type to student_quiz_sessions table
print("\n📋 Migration 1: Adding quiz_type column...")
try:
    cursor.execute(
        "ALTER TABLE student_quiz_sessions ADD COLUMN quiz_type TEXT DEFAULT 'regular' CHECK(quiz_type IN ('regular', 'cnacle', 'practice'))"
    )
    print("  ✅ Added quiz_type column to student_quiz_sessions")
except sqlite3.OperationalError as e:
    if "duplicate column" in str(e):
        print("  ⚠️  quiz_type column already exists (skipped)")
    else:
        print(f"  ❌ Error: {e}")
except Exception as e:
    print(f"  ❌ Error: {e}")

# Migration 2: Add category to questions table
print("\n📋 Migration 2: Adding category column...")
try:
    cursor.execute("ALTER TABLE questions ADD COLUMN category TEXT DEFAULT 'general'")
    print("  ✅ Added category column to questions")
except sqlite3.OperationalError as e:
    if "duplicate column" in str(e):
        print("  ⚠️  category column already exists (skipped)")
    else:
        print(f"  ❌ Error: {e}")
except Exception as e:
    print(f"  ❌ Error: {e}")

# Migration 3: Create practice_results table for practice/cnacle modes (no points)
print("\n📋 Migration 3: Creating practice_results table...")
try:
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS practice_results(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    quiz_type TEXT NOT NULL CHECK(quiz_type IN ('cnacle', 'practice')),
    score INTEGER NOT NULL,
    category TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
    )
    """)
    print("  ✅ Created practice_results table")
except Exception as e:
    print(f"  ❌ Error: {e}")

# Migration 4: Add is_practice column to student_quiz_answers
print("\n📋 Migration 4: Adding is_practice column to student_quiz_answers...")
try:
    cursor.execute(
        "ALTER TABLE student_quiz_answers ADD COLUMN is_practice INTEGER DEFAULT 0"
    )
    print("  ✅ Added is_practice column")
except sqlite3.OperationalError as e:
    if "duplicate column" in str(e):
        print("  ⚠️  is_practice column already exists (skipped)")
    else:
        print(f"  ❌ Error: {e}")
except Exception as e:
    print(f"  ❌ Error: {e}")

# Migration 5: Create practice_sessions table
print("\n📋 Migration 5: Creating practice_sessions table...")
try:
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS practice_sessions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    quiz_type TEXT NOT NULL CHECK(quiz_type IN ('cnacle', 'practice')),
    category TEXT,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    score INTEGER,
    total_questions INTEGER DEFAULT 5,
    FOREIGN KEY(student_id) REFERENCES users(id)
    )
    """)
    print("  ✅ Created practice_sessions table")
except Exception as e:
    print(f"  ❌ Error: {e}")

# Commit all changes
try:
    conn.commit()
    print("\n✅ All migrations committed successfully")
except Exception as e:
    print(f"❌ Error committing migrations: {e}")
    conn.close()
    exit(1)

try:
    conn.close()
    print("✅ Connection closed")
except Exception as e:
    print(f"❌ Error closing connection: {e}")
    exit(1)

# Verify migrations
print("\n🔍 Verifying migrations...")
try:
    verify_conn = sqlite3.connect(db_path)
    verify_cursor = verify_conn.cursor()

    # Check student_quiz_sessions columns
    verify_cursor.execute("PRAGMA table_info(student_quiz_sessions)")
    columns = [row[1] for row in verify_cursor.fetchall()]
    if "quiz_type" in columns:
        print("  ✅ student_quiz_sessions has quiz_type column")
    else:
        print("  ⚠️  student_quiz_sessions missing quiz_type column")

    # Check questions columns
    verify_cursor.execute("PRAGMA table_info(questions)")
    columns = [row[1] for row in verify_cursor.fetchall()]
    if "category" in columns:
        print("  ✅ questions has category column")
    else:
        print("  ⚠️  questions missing category column")

    # Check practice_results table
    verify_cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='practice_results'"
    )
    if verify_cursor.fetchone():
        print("  ✅ practice_results table exists")
    else:
        print("  ⚠️  practice_results table not found")

    # Check practice_sessions table
    verify_cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='practice_sessions'"
    )
    if verify_cursor.fetchone():
        print("  ✅ practice_sessions table exists")
    else:
        print("  ⚠️  practice_sessions table not found")

    # Check student_quiz_answers columns
    verify_cursor.execute("PRAGMA table_info(student_quiz_answers)")
    columns = [row[1] for row in verify_cursor.fetchall()]
    if "is_practice" in columns:
        print("  ✅ student_quiz_answers has is_practice column")
    else:
        print("  ⚠️  student_quiz_answers missing is_practice column")

    verify_conn.close()

except Exception as e:
    print(f"❌ Verification error: {e}")
    exit(1)

print("\n" + "=" * 70)
print("✨ MIGRATION COMPLETE!")
print("=" * 70)
print("\n🎓 Next steps:")
print("  1. Run: python add_questions.py (to add sample questions)")
print("  2. Run: python app.py")
print("\n" + "=" * 70)
