#!/usr/bin/env python3
import os

templates = {
    "templates/login.html": """<!DOCTYPE html>
<html>
<head>
<title>Login - AI Quiz App</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .login-container {
        background: white;
        padding: 40px;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        width: 100%;
        max-width: 400px;
    }
    .login-container h1 {
        margin-bottom: 30px;
        color: #333;
        text-align: center;
    }
    .form-control {
        margin-bottom: 15px;
        padding: 10px 15px;
        border-radius: 5px;
    }
    .btn-login {
        width: 100%;
        padding: 10px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        font-weight: bold;
        margin-top: 10px;
    }
    .btn-login:hover {
        background: linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%);
        color: white;
    }
    .signup-link {
        text-align: center;
        margin-top: 20px;
    }
    .signup-link p {
        margin-bottom: 10px;
        color: #666;
    }
    .signup-link a {
        color: #667eea;
        text-decoration: none;
        font-weight: bold;
        font-size: 16px;
    }
    .signup-link a:hover {
        text-decoration: underline;
    }
</style>
</head>

<body>

<div class="login-container">
    <h1>🎓 AI Quiz App</h1>

    <form method="POST">
        <input class="form-control" type="email" name="email" placeholder="📧 Email" required>
        <input class="form-control" type="password" name="password" placeholder="🔐 Password" required>

        <button class="btn btn-login" type="submit">Login</button>
    </form>

    <div class="signup-link">
        <p>Don't have an account?</p>
        <a href="/signup">👉 Sign Up Here</a>
    </div>
</div>

</body>
</html>""",
    "templates/signup.html": """<!DOCTYPE html>
<html>
<head>
<title>Sign Up - AI Quiz App</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .signup-container {
        background: white;
        padding: 40px;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        width: 100%;
        max-width: 400px;
    }
    .signup-container h1 {
        margin-bottom: 30px;
        color: #333;
        text-align: center;
    }
    .form-control, .form-select {
        margin-bottom: 15px;
        padding: 10px 15px;
        border-radius: 5px;
    }
    .btn-signup {
        width: 100%;
        padding: 10px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        font-weight: bold;
        margin-top: 10px;
    }
    .btn-signup:hover {
        background: linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%);
        color: white;
    }
    .login-link {
        text-align: center;
        margin-top: 20px;
    }
    .login-link p {
        margin-bottom: 10px;
        color: #666;
    }
    .login-link a {
        color: #667eea;
        text-decoration: none;
        font-weight: bold;
        font-size: 16px;
    }
    .login-link a:hover {
        text-decoration: underline;
    }
    .role-info {
        background: #f0f4ff;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 15px;
        font-size: 12px;
        color: #555;
    }
</style>
</head>

<body>

<div class="signup-container">
    <h1>📝 Create Account</h1>

    <form method="POST">
        <input class="form-control" type="text" name="username" placeholder="👤 Username" required>

        <input class="form-control" type="email" name="email" placeholder="📧 Email" required>

        <input class="form-control" type="password" name="password" placeholder="🔐 Password (min 6 chars)" required>

        <label class="form-label mt-3 mb-2"><strong>Select Your Role:</strong></label>
        <select class="form-select" name="role" required>
            <option value="">-- Choose Role --</option>
            <option value="student">👨‍🎓 Student (Take Quizzes)</option>
            <option value="teacher">👨‍🏫 Teacher (Create Questions)</option>
        </select>

        <div class="role-info">
            <strong>Note for Teachers:</strong> You must wait 24 hours after signup before adding questions.
        </div>

        <button class="btn btn-signup" type="submit">Sign Up</button>
    </form>

    <div class="login-link">
        <p>Already have an account?</p>
        <a href="/login">👉 Login Here</a>
    </div>
</div>

</body>
</html>""",
}


def fix_templates():
    print("🔧 Starting template fixes...")

    for filepath, content in templates.items():
        try:
            full_path = os.path.join(os.path.dirname(__file__), filepath)

            with open(full_path, "w", encoding="utf-8") as f:
                f.write(content)

            print(f"✅ Fixed: {filepath}")
        except Exception as e:
            print(f"❌ Error fixing {filepath}: {e}")

    print("\n✨ All templates fixed successfully!")
    print("📝 Now refresh your browser (Ctrl+R) to see the changes.")


if __name__ == "__main__":
    fix_templates()
