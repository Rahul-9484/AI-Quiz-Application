# 🎓 AI Quiz App - Complete Setup Guide

## 📋 Overview

AI Quiz App is a **multi-role quiz application** built with Flask and SQLite. It allows students to take quizzes, teachers to create questions, and admins to manage the system.

### Key Features:
- ✅ **Three User Roles**: Admin, Teacher, Student
- ✅ **Quiz System**: Random questions with 4 multiple choice options
- ✅ **Scoring**: Automatic scoring and result tracking
- ✅ **Leaderboard**: Top student rankings
- ✅ **Activity Logs**: Track all user actions
- ✅ **Secure Authentication**: Password hashing with werkzeug
- ✅ **Input Validation**: All forms validated
- ✅ **Error Handling**: Comprehensive error management

---

## 🚀 Quick Start

### Step 1: Install Dependencies

```bash
pip install flask werkzeug
```

### Step 2: Initialize Database

```bash
python init_db.py
```

You should see:
```
✅ Database created successfully!

📋 Default Admin Credentials:
   Email: admin@mail.com
   Password: admin123

🚀 Ready to run the app!
```

### Step 3: Run the Application

```bash
python app.py
```

Visit: **http://127.0.0.1:5000/login**

---

## 👥 User Roles & Features

### 👨‍💼 **Admin**
**Credentials:**
- Email: `admin@mail.com`
- Password: `admin123`

**Capabilities:**
- ✅ Add questions (immediately)
- ✅ Delete questions
- ✅ View all logs (admin, teacher, student)
- ✅ View leaderboard

**Dashboard:** `/admin_dashboard`

---

### 👨‍🏫 **Teacher**
**How to Signup:**
1. Go to `/signup`
2. Fill form:
   - Username: Any name
   - Email: unique email
   - Password: 6+ characters
   - Role: Select "Teacher"
3. Click Sign Up
4. **Wait 24 hours** before adding questions

**Capabilities:**
- ✅ Add questions (after 24 hours)
- ❌ Cannot delete questions
- ✅ View their question logs
- ✅ View leaderboard

**Dashboard:** `/teacher_dashboard`

---

### 👨‍🎓 **Student**
**How to Signup:**
1. Go to `/signup`
2. Fill form:
   - Username: Any name
   - Email: unique email
   - Password: 6+ characters
   - Role: Select "Student"
3. Click Sign Up
4. Login immediately

**Capabilities:**
- ✅ Take quizzes (5 questions, 20 seconds each)
- ✅ See results and score
- ✅ View leaderboard
- ✅ View their quiz logs

**Dashboard:** `/student_dashboard`

---

## 🎯 Features Explained

### Quiz Taking Process
1. **Start Quiz** → Redirects to `/start_quiz`
2. **Question Display** → Random question with 4 options
3. **Timer** → 20 seconds per question
4. **Answer Selection** → Click radio button to select answer
5. **Auto-submit** → Auto-submits when timer ends (if answer selected)
6. **Next Question** → After 5 questions, redirects to results
7. **Results Page** → Shows score (0-5)

### Question Management
**Adding Questions:**
- Admin: Can add immediately
- Teacher: Must wait 24 hours after signup
- Student: Cannot add

**Question Fields:**
- Question text
- 4 options (option1, option2, option3, option4)
- Correct answer (must be one of the options)
- Difficulty: easy, medium, hard

**Deleting Questions:**
- Admin only
- Provides question ID
- Logs the deletion

### Leaderboard
- Shows top students by best score
- Displays:
  - Username
  - Best score
  - Number of attempts
- Sorted by best score (descending) and attempts

### Activity Logs
**Admin Logs:**
- Track when admins add/delete questions
- Timestamp for each action

**Teacher Logs:**
- Track which questions teachers added
- Question ID and timestamp

**Student Logs:**
- Track each quiz attempt
- Question answered, answer given, time taken

---

## 🔐 Security Features

### Password Hashing
- Uses `werkzeug.security.generate_password_hash()`
- Passwords are never stored in plain text
- Uses SHA1 with salt by default

### Input Validation
- Email format validation
- Password minimum 6 characters
- Username minimum 3 characters
- Role validation (only admin, teacher, student)
- Duplicate email checking
- SQL injection prevention (parameterized queries)

### Database Security
- Foreign key constraints
- Unique constraints on email
- CHECK constraints on role and difficulty
- Proper connection timeout (10 seconds)

### Session Security
- Session cookies are HTTP-only
- Session timeout: 24 hours
- Clear session on logout

---

## 📁 Project Structure

```
ai_quiz_app/
├── app.py                 # Main Flask application
├── init_db.py            # Database initialization script
├── database.db           # SQLite database (created after init_db.py)
├── fix_templates.py      # Helper script to fix templates
│
├── templates/            # HTML templates
│   ├── login.html        # Login page
│   ├── signup.html       # Sign up page
│   ├── admin_dashboard.html
│   ├── teacher_dashboard.html
│   ├── student_dashboard.html
│   ├── add_question.html
│   ├── delete_question.html
│   ├── quiz.html
│   ├── result.html
│   ├── leaderboard.html
│   ├── admin_logs.html
│   ├── teacher_logs.html
│   ├── student_logs.html
│   ├── 404.html          # Page not found
│   └── 500.html          # Server error
│
└── static/               # CSS, JS, images
    ├── css/
    └── js/
```

---

## 🗄️ Database Schema

### Users Table
```sql
CREATE TABLE users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT CHECK(role IN ('admin', 'teacher', 'student')),
  created_at TEXT NOT NULL
)
```

### Questions Table
```sql
CREATE TABLE questions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question TEXT NOT NULL,
  option1 TEXT NOT NULL,
  option2 TEXT NOT NULL,
  option3 TEXT NOT NULL,
  option4 TEXT NOT NULL,
  correct_answer TEXT NOT NULL,
  difficulty TEXT CHECK(difficulty IN ('easy', 'medium', 'hard')),
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(created_by) REFERENCES users(id)
)
```

### Results Table
```sql
CREATE TABLE results(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  score INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id)
)
```

### Logs Tables
- **admin_logs**: Tracks admin actions
- **teacher_logs**: Tracks teacher question additions
- **student_logs**: Tracks student quiz attempts

---

## 🛠️ Troubleshooting

### "Database is locked" Error
**Solution:**
- The database timeout is set to 10 seconds
- If still getting error, close all other connections to database.db
- Delete database.db and run `python init_db.py` again

### "Email already exists" Error
**Solution:**
- Use a different email address
- Or delete the user from database and try again

### "Teacher cannot add question for first 24 hours"
**Solution:**
- This is by design - wait 24 hours after signup
- For testing, admin can add questions immediately

### Login not working
**Solution:**
- Make sure you're using correct email and password
- Check if account exists (signup first if needed)
- Default admin: admin@mail.com / admin123

### Quiz Timer Issues
**Solution:**
- Make sure JavaScript is enabled in browser
- Timer should show countdown from 20 seconds
- Auto-submit only works if answer is selected

---

## 📝 Common Workflows

### Admin Workflow
1. Login with admin credentials
2. Click "Add Question" → Fill form → Submit
3. Click "Delete Question" → Enter question ID → Submit
4. View logs to see activities

### Teacher Workflow
1. Sign up as teacher
2. Wait 24 hours
3. Login to teacher dashboard
4. Click "Add Question" → Fill form → Submit
5. View teacher logs to see added questions

### Student Workflow
1. Sign up as student
2. Login to student dashboard
3. Click "Start Quiz"
4. Select answer for each question (20 seconds each)
5. View results after 5 questions
6. Check leaderboard to see rankings

---

## 🔄 API Routes

### Authentication
- `GET/POST /login` - User login
- `GET/POST /signup` - New user registration
- `GET /logout` - User logout

### Dashboards
- `GET /admin_dashboard` - Admin panel
- `GET /teacher_dashboard` - Teacher panel
- `GET /student_dashboard` - Student panel

### Questions
- `GET/POST /add_question` - Add new question
- `GET/POST /delete_question` - Delete question

### Quiz
- `GET /start_quiz` - Start quiz session
- `POST /submit_answer` - Submit answer to question
- `GET /result` - View quiz result

### Leaderboard
- `GET /leaderboard` - View top students

### Logs
- `GET /admin_logs` - View admin activity logs
- `GET /teacher_logs` - View teacher activity logs
- `GET /student_logs` - View student activity logs

---

## 🎓 Testing Instructions

### Test Admin
```
Email: admin@mail.com
Password: admin123
```

### Create Test Teacher
1. Go to /signup
2. Username: `Teacher1`
3. Email: `teacher1@test.com`
4. Password: `test123`
5. Role: Teacher
6. Wait 24 hours (or admin can add questions for testing)

### Create Test Student
1. Go to /signup
2. Username: `Student1`
3. Email: `student1@test.com`
4. Password: `test123`
5. Role: Student
6. Can login immediately

---

## 📊 Performance Tips

1. **Database Optimization:**
   - Indexes on frequently queried columns
   - Use LIMIT in SELECT queries
   - Commit transactions efficiently

2. **Response Time:**
   - Database timeout: 10 seconds
   - Connection pooling recommended for production
   - Caching for leaderboard

3. **Security in Production:**
   - Change `app.secret_key` to random string
   - Set `SESSION_COOKIE_SECURE = True` (requires HTTPS)
   - Use environment variables for config
   - Set `debug=False` in production

---

## 🚨 Known Limitations

1. **Single Database File:** SQLite is not ideal for high-concurrency apps
   - **Solution:** Use PostgreSQL/MySQL for production

2. **No Email Verification:** Emails not verified during signup
   - **Solution:** Add email verification step

3. **No Password Reset:** No forgot password feature
   - **Solution:** Implement password reset via email

4. **No Question Categories:** All questions in one pool
   - **Solution:** Add category field to questions table

5. **No Question Editing:** Can only add/delete
   - **Solution:** Add edit question functionality

---

## 📚 Future Enhancements

- [ ] Question categories/topics
- [ ] Difficulty-based quiz filtering
- [ ] Time-based leaderboard (weekly, monthly)
- [ ] Admin dashboard with statistics
- [ ] Email notifications
- [ ] User profile editing
- [ ] Question bank export/import
- [ ] Mobile-responsive design improvements
- [ ] Dark mode support
- [ ] Two-factor authentication

---

## 📞 Support

**For issues or questions:**
1. Check troubleshooting section above
2. Review error messages in console
3. Check database.db exists and is readable
4. Ensure all dependencies are installed

---

## 📄 License

This project is provided as-is for educational purposes.

---

## 🎉 Enjoy Using AI Quiz App!

Happy quizzing! 🚀