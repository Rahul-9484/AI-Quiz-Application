import sqlite3
import sys
from datetime import datetime, timedelta

from werkzeug.security import check_password_hash, generate_password_hash

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


# Test script for User Management Feature
def test_user_management():
    """Test script to verify user management functionality"""

    db_path = "database.db"

    print("=" * 70)
    print("🧪 USER MANAGEMENT FEATURE TEST")
    print("=" * 70)

    try:
        # Connect to database
        conn = sqlite3.connect(db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        print("\n✅ Database connection successful")

        # Test 1: Check if users table exists
        print("\n" + "=" * 70)
        print("TEST 1: Verify Users Table")
        print("=" * 70)
        try:
            cursor.execute("SELECT COUNT(*) FROM users")
            count = cursor.fetchone()[0]
            print(f"✅ Users table exists with {count} user(s)")
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 2: Verify admin user exists
        print("\n" + "=" * 70)
        print("TEST 2: Verify Default Admin User")
        print("=" * 70)
        try:
            cursor.execute(
                "SELECT id, username, email, role FROM users WHERE role='admin' LIMIT 1"
            )
            admin = cursor.fetchone()
            if admin:
                print(f"✅ Admin user found:")
                print(f"   ID: {admin[0]}")
                print(f"   Username: {admin[1]}")
                print(f"   Email: {admin[2]}")
                print(f"   Role: {admin[3]}")
            else:
                print("⚠️  No admin user found")
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 3: Check admin_logs table
        print("\n" + "=" * 70)
        print("TEST 3: Verify Admin Logs Table")
        print("=" * 70)
        try:
            cursor.execute("SELECT COUNT(*) FROM admin_logs")
            count = cursor.fetchone()[0]
            print(f"✅ Admin logs table exists with {count} log(s)")
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 4: Test password hashing
        print("\n" + "=" * 70)
        print("TEST 4: Verify Password Hashing")
        print("=" * 70)
        try:
            test_password = "test_password_123"
            hashed = generate_password_hash(test_password)
            is_valid = check_password_hash(hashed, test_password)
            if is_valid:
                print(f"✅ Password hashing works correctly")
                print(f"   Original: {test_password}")
                print(f"   Hashed: {hashed[:50]}...")
            else:
                print("❌ Password hash validation failed")
                return False
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 5: Check user roles
        print("\n" + "=" * 70)
        print("TEST 5: Check User Roles Distribution")
        print("=" * 70)
        try:
            cursor.execute("SELECT role, COUNT(*) as count FROM users GROUP BY role")
            roles = cursor.fetchall()
            for role_data in roles:
                role = role_data[0]
                count = role_data[1]
                icon = (
                    "👑" if role == "admin" else "👨‍🏫" if role == "teacher" else "👨‍🎓"
                )
                print(f"   {icon} {role.capitalize()}: {count}")
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 6: Verify teacher restriction
        print("\n" + "=" * 70)
        print("TEST 6: Verify Teacher 24-Hour Restriction Logic")
        print("=" * 70)
        try:
            cursor.execute(
                "SELECT username, created_at FROM users WHERE role='teacher' LIMIT 1"
            )
            teacher = cursor.fetchone()
            if teacher:
                username = teacher[0]
                created_at = datetime.fromisoformat(teacher[1])
                now = datetime.now()
                time_elapsed = now - created_at
                can_add = time_elapsed >= timedelta(hours=24)

                print(f"✅ Teacher found: {username}")
                print(f"   Created: {created_at}")
                print(f"   Time elapsed: {time_elapsed}")
                print(f"   Can add questions: {'Yes' if can_add else 'No'}")
            else:
                print("⚠️  No teacher user found to test restriction")
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 7: Verify unique constraints
        print("\n" + "=" * 70)
        print("TEST 7: Verify Unique Constraints")
        print("=" * 70)
        try:
            cursor.execute("SELECT username, email FROM users")
            users = cursor.fetchall()
            usernames = [u[0] for u in users]
            emails = [u[1] for u in users]

            username_unique = len(usernames) == len(set(usernames))
            email_unique = len(emails) == len(set(emails))

            if username_unique:
                print("✅ All usernames are unique")
            else:
                print("❌ Duplicate usernames found")
                return False

            if email_unique:
                print("✅ All emails are unique")
            else:
                print("❌ Duplicate emails found")
                return False
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        # Test 8: Check database integrity
        print("\n" + "=" * 70)
        print("TEST 8: Database Integrity Check")
        print("=" * 70)
        try:
            required_tables = [
                "users",
                "questions",
                "results",
                "admin_logs",
                "teacher_logs",
                "student_logs",
            ]
            all_exist = True

            for table in required_tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                print(f"   ✅ {table}: {count} records")

            print("✅ All required tables exist")
        except Exception as e:
            print(f"❌ Error: {e}")
            return False

        conn.close()
        print("\n" + "=" * 70)
        print("🎉 ALL TESTS PASSED!")
        print("=" * 70)
        print("\n📋 Summary:")
        print("   ✅ Database connection working")
        print("   ✅ Users table verified")
        print("   ✅ Admin user exists")
        print("   ✅ Admin logs table verified")
        print("   ✅ Password hashing working")
        print("   ✅ User roles distributed correctly")
        print("   ✅ Teacher restriction logic valid")
        print("   ✅ Unique constraints enforced")
        print("   ✅ Database integrity confirmed")
        print("\n✨ User Management feature is ready to use!")
        print("\nNext steps:")
        print("   1. Run: python app.py")
        print("   2. Login: admin@mail.com / admin123")
        print("   3. Click: 👥 Manage Users (on Admin Dashboard)")
        print("=" * 70)

        return True

    except Exception as e:
        print(f"\n❌ Critical error: {e}")
        return False


if __name__ == "__main__":
    success = test_user_management()
    sys.exit(0 if success else 1)
