import sqlite3
from datetime import datetime, timedelta

from flask import Flask, flash, redirect, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = "your_secret_key_change_this_in_production"
app.config["SESSION_COOKIE_SECURE"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=24)

DATABASE = "database.db"

TOPIC_CATALOG = [
    {
        "slug": "python-basics",
        "name": "Python Basics",
        "description": "Practice lists, functions, print statements, and core Python syntax.",
        "keywords": ["python", "function", "list", "len()", "print("],
    },
    {
        "slug": "science",
        "name": "Science",
        "description": "Revise biology, chemistry, physics, and space-related questions.",
        "keywords": ["red planet", "plants", "cell", "h2o", "speed of light"],
    },
    {
        "slug": "mathematics",
        "name": "Mathematics",
        "description": "Sharpen arithmetic, percentages, geometry, and square roots.",
        "keywords": ["plus", "divided", "percent", "rectangle", "square root"],
    },
    {
        "slug": "geography",
        "name": "Geography",
        "description": "Explore capitals, countries, continents, oceans, and world facts.",
        "keywords": ["capital", "ocean", "continent", "country", "population"],
    },
    {
        "slug": "technology",
        "name": "Technology",
        "description": "Focus on AI, web fundamentals, and common internet terms.",
        "keywords": ["ai stand for", "web pages", "http"],
    },
    {
        "slug": "sports",
        "name": "Sports",
        "description": "Test yourself on cricket and tennis basics.",
        "keywords": ["cricket", "tennis"],
    },
    {
        "slug": "history-art",
        "name": "History & Art",
        "description": "Mix historical events with famous art knowledge.",
        "keywords": ["mona lisa", "world war ii"],
    },
]

# ================= DATABASE HELPERS =================


def get_db_connection():
    """Create a database connection with timeout and proper error handling"""
    try:
        conn = sqlite3.connect(DATABASE, timeout=10.0)
        conn.isolation_level = None  # Autocommit mode
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        print(f"Database connection error: {e}")
        raise


def close_db_connection(conn):
    """Close database connection safely"""
    if conn:
        try:
            conn.close()
        except sqlite3.Error as e:
            print(f"Error closing database: {e}")


def validate_email(email):
    """Basic email validation"""
    return "@" in email and "." in email


def validate_password(password):
    """Validate password strength"""
    return len(password) >= 6


def is_email_exists(email):
    """Check if email already exists"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id FROM users WHERE email=?", (email,))
        exists = cursor.fetchone() is not None
        return exists
    finally:
        close_db_connection(conn)


def ensure_activity_tables():
    """Create extra activity/logging tables if missing (safe on existing DB)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = ON")

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS teacher_activity_logs(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              teacher_id INTEGER NOT NULL,
              action TEXT NOT NULL,
              question_id INTEGER,
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(teacher_id) REFERENCES users(id),
              FOREIGN KEY(question_id) REFERENCES questions(id)
            )
            """
        )

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS student_quiz_sessions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id INTEGER NOT NULL,
              started_at TEXT NOT NULL,
              ended_at TEXT,
              score INTEGER,
              total_questions INTEGER DEFAULT 5,
              FOREIGN KEY(student_id) REFERENCES users(id)
            )
            """
        )

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS student_quiz_answers(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              session_id INTEGER NOT NULL,
              student_id INTEGER NOT NULL,
              question_id INTEGER NOT NULL,
              selected_answer TEXT NOT NULL,
              correct_answer TEXT NOT NULL,
              is_correct INTEGER NOT NULL,
              time_taken INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(session_id) REFERENCES student_quiz_sessions(id),
              FOREIGN KEY(student_id) REFERENCES users(id),
              FOREIGN KEY(question_id) REFERENCES questions(id)
            )
            """
        )

        conn.commit()
    finally:
        close_db_connection(conn)


def ensure_topic_tables():
    """Create topic management tables if missing."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = ON")

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS topics(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL UNIQUE,
              description TEXT,
              created_by INTEGER,
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(created_by) REFERENCES users(id)
            )
            """
        )

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS topic_questions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              topic_id INTEGER NOT NULL,
              question_id INTEGER NOT NULL,
              created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
              UNIQUE(topic_id, question_id),
              FOREIGN KEY(topic_id) REFERENCES topics(id),
              FOREIGN KEY(question_id) REFERENCES questions(id)
            )
            """
        )

        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_topic_questions_topic_id ON topic_questions(topic_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_topic_questions_question_id ON topic_questions(question_id)"
        )

        conn.commit()
    finally:
        close_db_connection(conn)


def log_admin(action: str):
    if session.get("role") != "admin" or not session.get("user_id"):
        return
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO admin_logs(admin_id, action, created_at) VALUES (?, ?, ?)",
            (session.get("user_id"), action, datetime.now().isoformat()),
        )
        conn.commit()
    except Exception as e:
        print(f"Admin log error: {e}")
    finally:
        close_db_connection(conn)


def log_teacher(action: str, question_id=None):
    if session.get("role") != "teacher" or not session.get("user_id"):
        return
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            INSERT INTO teacher_activity_logs(teacher_id, action, question_id, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (session.get("user_id"), action, question_id, datetime.now().isoformat()),
        )
        conn.commit()
    except Exception as e:
        print(f"Teacher log error: {e}")
    finally:
        close_db_connection(conn)


def can_manage_topics():
    """Teachers and admins can manage topics."""
    return session.get("role") in {"teacher", "admin"}


def can_modify_questions():
    """Question content changes are restricted for new teachers."""
    if session.get("role") == "admin":
        return True
    if session.get("role") == "teacher":
        return teacher_can_add(session.get("user_id"))
    return False


def finalize_quiz_attempt(cursor, quiz_session_id):
    session["last_quiz_review_items"] = list(session.get("quiz_review_items", []))
    cursor.execute(
        """
        INSERT INTO results(user_id, score, created_at)
        VALUES (?, ?, ?)
        """,
        (
            session["user_id"],
            session.get("score", 0),
            datetime.now().isoformat(),
        ),
    )

    if session.get("role") == "student" and quiz_session_id:
        session["last_quiz_session_id"] = quiz_session_id
        try:
            cursor.execute(
                """
                UPDATE student_quiz_sessions
                SET ended_at=?, score=?
                WHERE id=? AND student_id=?
                """,
                (
                    datetime.now().isoformat(),
                    session.get("score", 0),
                    quiz_session_id,
                    session.get("user_id"),
                ),
            )
        except Exception as e:
            print(f"Quiz session end log error: {e}")


def clear_active_quiz_state(clear_last_session=True):
    """Clear current in-progress quiz state from the session."""
    session.pop("score", None)
    session.pop("count", None)
    session.pop("answered_questions", None)
    session.pop("quiz_session_id", None)
    session.pop("quiz_total_questions", None)
    session.pop("quiz_topic_id", None)
    session.pop("quiz_topic_slug", None)
    session.pop("quiz_review_items", None)
    if clear_last_session:
        session.pop("last_quiz_session_id", None)
        session.pop("last_quiz_review_items", None)


def get_dashboard_route():
    """Return the most suitable dashboard URL for the current user role."""
    role = session.get("role")
    if role == "admin":
        return "/admin_dashboard"
    if role == "teacher":
        return "/teacher_dashboard"
    return "/student_dashboard"


def format_display_datetime(value):
    """Format ISO datetime as 02:04 PM DATE 30/03/2026."""
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(value).strftime("%I:%M %p DATE %d/%m/%Y")
    except (TypeError, ValueError):
        return str(value)


# ================= AUTH HELPERS =================


def login_required():
    """Check if user is logged in"""
    return "user_id" in session


def teacher_can_add(user_id):
    """Check if teacher can add questions (24 hours after signup)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT created_at FROM users WHERE id=?", (user_id,))
        data = cursor.fetchone()

        if not data:
            return False

        created_time = datetime.fromisoformat(data[0])
        return datetime.now() >= created_time + timedelta(hours=24)
    finally:
        close_db_connection(conn)


def get_user(user_id):
    """Get user by ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users WHERE id=?", (user_id,))
        return cursor.fetchone()
    finally:
        close_db_connection(conn)


def get_topic_config(topic_slug):
    """Return topic config for a known topic slug."""
    for topic in TOPIC_CATALOG:
        if topic["slug"] == topic_slug:
            return topic
    return None


def get_db_topic(topic_id):
    """Fetch a topic from the topics table."""
    if topic_id is None:
        return None

    try:
        ensure_topic_tables()
    except Exception as e:
        print(f"ensure_topic_tables failed: {e}")
        return None

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT id, name, description FROM topics WHERE id=?",
            (topic_id,),
        )
        row = cursor.fetchone()
        if not row:
            return None
        return {
            "id": row["id"],
            "name": row["name"],
            "description": row["description"],
            "source": "db",
        }
    finally:
        close_db_connection(conn)


def resolve_quiz_topic(topic_slug=None, topic_id=None):
    """Resolve either a DB-backed topic or a fallback catalog topic."""
    if topic_id is not None:
        return get_db_topic(topic_id)

    topic = get_topic_config(topic_slug)
    if not topic:
        return None

    return {
        "slug": topic["slug"],
        "name": topic["name"],
        "description": topic["description"],
        "source": "catalog",
    }


def get_topic_filter(topic_slug=None, topic_id=None):
    """Build a SQL filter for topic-specific question lookup."""
    if topic_id is not None:
        return (
            "id IN (SELECT question_id FROM topic_questions WHERE topic_id = ?)",
            [topic_id],
        )

    topic = get_topic_config(topic_slug)
    if not topic:
        return "", []

    clauses = ["LOWER(question) LIKE ?" for _ in topic["keywords"]]
    params = [f"%{keyword.lower()}%" for keyword in topic["keywords"]]
    return "(" + " OR ".join(clauses) + ")", params


def build_fallback_topics():
    """Provide dashboard topics even when the topics table is not configured."""
    topics = []
    for index, topic in enumerate(TOPIC_CATALOG, start=1):
        question_count = count_questions(topic["slug"])
        topics.append(
            {
                "id": index,
                "slug": topic["slug"],
                "name": topic["name"],
                "description": topic["description"],
                "question_count": question_count,
                "practice_url": (
                    f"/start_quiz?topic={topic['slug']}"
                    if question_count > 0
                    else "/start_quiz"
                ),
            }
        )
    return topics


def get_random_question(exclude_ids=None, topic_slug=None, topic_id=None):
    """Get a random question, optionally excluding IDs or filtering by topic."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        filters = []
        params = []

        topic_clause, topic_params = get_topic_filter(topic_slug, topic_id)
        if topic_clause:
            filters.append(topic_clause)
            params.extend(topic_params)

        if exclude_ids:
            placeholders = ",".join(["?" for _ in exclude_ids])
            filters.append(f"id NOT IN ({placeholders})")
            params.extend(exclude_ids)

        query = "SELECT * FROM questions"
        if filters:
            query += " WHERE " + " AND ".join(filters)
        query += " ORDER BY RANDOM() LIMIT 1"
        cursor.execute(query, params)

        question = cursor.fetchone()
        return question
    finally:
        close_db_connection(conn)


def get_difficulty_question(difficulty, exclude_ids=None):
    """Get a random question by difficulty level"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        if exclude_ids:
            placeholders = ",".join(["?" for _ in exclude_ids])
            query = f"""
            SELECT * FROM questions
            WHERE difficulty = ? AND id NOT IN ({placeholders})
            ORDER BY RANDOM() LIMIT 1
            """
            cursor.execute(query, [difficulty] + exclude_ids)
        else:
            cursor.execute(
                "SELECT * FROM questions WHERE difficulty = ? ORDER BY RANDOM() LIMIT 1",
                (difficulty,),
            )

        question = cursor.fetchone()
        return question
    finally:
        close_db_connection(conn)


def count_questions(topic_slug=None, topic_id=None):
    """Get total number of questions in database, optionally filtered by topic."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        query = "SELECT COUNT(*) FROM questions"
        params = []
        topic_clause, topic_params = get_topic_filter(topic_slug, topic_id)
        if topic_clause:
            query += f" WHERE {topic_clause}"
            params.extend(topic_params)

        cursor.execute(query, params)
        count = cursor.fetchone()[0]
        return count
    finally:
        close_db_connection(conn)


# ================= AUTH =================


@app.route("/")
def home():
    return redirect("/login")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()

        if not email or not password:
            flash("Email and password are required", "error")
            return render_template("login.html")

        if not validate_email(email):
            flash("Invalid email format", "error")
            return render_template("login.html")

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("SELECT * FROM users WHERE email=?", (email,))
            user = cursor.fetchone()

            if user and check_password_hash(user[3], password):
                session.permanent = True
                session["user_id"] = user[0]
                session["role"] = user[4]
                session["username"] = user[1]

                # Basic login activity logging (best-effort)
                if user[4] == "admin":
                    log_admin("Logged in")
                elif user[4] == "teacher":
                    log_teacher("Logged in")

                if user[4] == "admin":
                    return redirect("/admin_dashboard")
                elif user[4] == "teacher":
                    return redirect("/teacher_dashboard")
                else:
                    return redirect("/student_dashboard")

            flash("Invalid email or password", "error")
            return render_template("login.html")
        finally:
            close_db_connection(conn)

    return render_template("login.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        role = request.form.get("role", "student")

        if not username or not email or not password:
            flash("All fields are required", "error")
            return render_template("signup.html")

        if len(username) < 3:
            flash("Username must be at least 3 characters", "error")
            return render_template("signup.html")

        if not validate_email(email):
            flash("Invalid email format", "error")
            return render_template("signup.html")

        if not validate_password(password):
            flash("Password must be at least 6 characters", "error")
            return render_template("signup.html")

        if role not in ["student", "teacher"]:
            flash("Invalid role selected", "error")
            return render_template("signup.html")

        if is_email_exists(email):
            flash("Email already exists", "error")
            return render_template("signup.html")

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            hashed_password = generate_password_hash(password)
            cursor.execute(
                """
            INSERT INTO users(username, email, password, role, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
                (username, email, hashed_password, role, datetime.now().isoformat()),
            )
            conn.commit()

            flash("Signup successful! Please login.", "success")
            return redirect("/login")
        except sqlite3.IntegrityError:
            flash("Email already exists", "error")
            return render_template("signup.html")
        except sqlite3.Error as e:
            flash("Error creating account. Please try again.", "error")
            print(f"Signup error: {e}")
            return render_template("signup.html")
        finally:
            close_db_connection(conn)

    return render_template("signup.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully", "success")
    return redirect("/login")


# ================= DASHBOARDS =================


@app.route("/admin_dashboard")
def admin_dashboard():
    if not login_required():
        return redirect("/login")

    if session.get("role") != "admin":
        flash("Access denied", "error")
        return redirect("/student_dashboard")

    log_admin("Viewed admin dashboard")
    return render_template("admin_dashboard.html", username=session.get("username"))


@app.route("/teacher_dashboard")
def teacher_dashboard():
    if not login_required():
        return redirect("/login")

    if session.get("role") != "teacher":
        flash("Access denied", "error")
        return redirect("/student_dashboard")

    log_teacher("Viewed teacher dashboard")

    try:
        ensure_topic_tables()
    except Exception as e:
        print(f"ensure_topic_tables failed: {e}")

    stats = {
        "created_questions": 0,
        "topics_count": 0,
        "linked_questions": 0,
    }
    can_add = can_modify_questions()

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "SELECT COUNT(*) FROM questions WHERE created_by=?",
            (session.get("user_id"),),
        )
        stats["created_questions"] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM topics")
        stats["topics_count"] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM topic_questions")
        stats["linked_questions"] = cursor.fetchone()[0]
    except Exception as e:
        print(f"Teacher dashboard stats error: {e}")
    finally:
        try:
            close_db_connection(conn)
        except Exception:
            pass

    return render_template(
        "teacher_dashboard.html",
        username=session.get("username"),
        can_add_questions=can_add,
        stats=stats,
    )


@app.route("/student_dashboard")
def student_dashboard():
    if not login_required():
        return redirect("/login")

    return render_template("student_dashboard.html", username=session.get("username"))


# Minimal placeholder routes so dashboard links don't 404.
@app.route("/practice")
def practice():
    if not login_required():
        return redirect("/login")
    # Minimal practice page (template: templates/practice.html)
    return render_template("practice.html")


@app.route("/skill_prediction")
def skill_prediction():
    if not login_required():
        return redirect("/login")

    user_id = session.get("user_id")
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get all results for this user
        cursor.execute(
            "SELECT score FROM results WHERE user_id=? ORDER BY created_at DESC",
            (user_id,),
        )
        results = cursor.fetchall()

        if not results:
            skill = "No Data"
            skill_message = "You haven't taken any quizzes yet. Start a quiz to get your skill prediction!"
            quiz_count = 0
        else:
            # Calculate average score
            scores = [r[0] for r in results]
            average_score = sum(scores) / len(scores)
            quiz_count = len(scores)

            # Determine skill level based on average score
            if average_score >= 80:
                skill = "Expert"
            elif average_score >= 60:
                skill = "Advanced"
            elif average_score >= 40:
                skill = "Intermediate"
            else:
                skill = "Beginner"

            skill_message = f"Based on {quiz_count} quiz attempts, your average score is {average_score:.1f}%"

        return render_template(
            "skill.html",
            skill=skill,
            skill_message=skill_message,
            quiz_count=quiz_count,
        )
    except Exception as e:
        print(f"Error calculating skill: {e}")
        return render_template(
            "skill.html",
            skill="Error",
            skill_message="Could not calculate skill level",
            quiz_count=0,
        )
    finally:
        try:
            close_db_connection(conn)
        except Exception:
            pass


@app.route("/resources")
def resources():
    if not login_required():
        return redirect("/login")

    # Try to fetch resources from a `resources` table if it exists; otherwise pass an empty list.
    resources = []
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, title, url, description, note FROM resources ORDER BY id DESC LIMIT 100"
        )
        rows = cursor.fetchall()
        # rows are sqlite3.Row objects (row_factory set), convert to simple dicts for the template
        resources = [
            {
                "id": r["id"],
                "title": r["title"],
                "url": r["url"],
                "description": r["description"],
                "note": r["note"],
            }
            for r in rows
        ]
    except Exception:
        # If table doesn't exist or any other DB error, render template with empty resources
        resources = []
    finally:
        try:
            close_db_connection(conn)
        except Exception:
            pass

    return render_template("resources.html", resources=resources)


@app.route("/topics")
def topics():
    if not login_required():
        return redirect("/login")

    try:
        ensure_topic_tables()
    except Exception as e:
        print(f"ensure_topic_tables failed: {e}")

    # Try to fetch topics from a `topics` table if it exists; otherwise show defaults.
    topics_list = []
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT topics.id,
                   topics.name,
                   topics.description,
                   COUNT(topic_questions.question_id) AS question_count
            FROM topics
            LEFT JOIN topic_questions ON topic_questions.topic_id = topics.id
            GROUP BY topics.id, topics.name, topics.description
            ORDER BY topics.name
            LIMIT 200
            """
        )
        rows = cursor.fetchall()
        topics_list = [
            {
                "id": r["id"],
                "name": r["name"],
                "description": r["description"],
                "question_count": r["question_count"],
                "practice_url": f"/start_quiz?topic_id={r['id']}",
            }
            for r in rows
        ]
    except Exception:
        topics_list = []
    finally:
        try:
            close_db_connection(conn)
        except Exception:
            pass

    if not topics_list:
        topics_list = build_fallback_topics()

    return render_template("topics.html", topics=topics_list)


@app.route("/results")
def results():
    if not login_required():
        return redirect("/login")

    results_data = []
    latest_score = None
    latest_total = None
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        if session.get("role") == "student":
            cursor.execute(
                """
                SELECT id, score, total_questions, ended_at, started_at
                FROM student_quiz_sessions
                WHERE student_id=? AND score IS NOT NULL
                ORDER BY COALESCE(ended_at, started_at) DESC
                LIMIT 100
                """,
                (session.get("user_id"),),
            )
            rows = cursor.fetchall()
            results_data = [
                {
                    "id": row["id"],
                    "score": row["score"],
                    "total": row["total_questions"] or 5,
                    "when": format_display_datetime(row["ended_at"] or row["started_at"]),
                    "notes": "Completed quiz",
                }
                for row in rows
            ]
        else:
            cursor.execute(
                """
                SELECT id, score, created_at
                FROM results
                WHERE user_id=?
                ORDER BY created_at DESC
                LIMIT 100
                """,
                (session.get("user_id"),),
            )
            rows = cursor.fetchall()
            results_data = [
                {
                    "id": row["id"],
                    "score": row["score"],
                    "total": 5,
                    "when": format_display_datetime(row["created_at"]),
                    "notes": "Completed quiz",
                }
                for row in rows
            ]

        if results_data:
            latest_score = results_data[0]["score"]
            latest_total = results_data[0]["total"]
    except Exception as e:
        print(f"Error fetching results: {e}")
        results_data = []
    finally:
        try:
            close_db_connection(conn)
        except Exception:
            pass

    return render_template(
        "results.html",
        results=results_data,
        latest_score=latest_score,
        latest_total=latest_total,
    )


# ================= USER MANAGEMENT (ADMIN ONLY) =================


@app.route("/manage_users")
def manage_users():
    """Admin page to view and manage all users with filtering"""
    if not login_required():
        return redirect("/login")

    if session.get("role") != "admin":
        flash("Access denied. Admin only.", "error")
        return redirect("/student_dashboard")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Get filter parameter
        role_filter = request.args.get("role", "all").strip()

        # Build query based on filter
        if role_filter in ["admin", "teacher", "student"]:
            cursor.execute(
                "SELECT id, username, email, role, created_at FROM users WHERE role=? ORDER BY created_at DESC",
                (role_filter,),
            )
        else:
            cursor.execute(
                "SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC"
            )

        users = cursor.fetchall()

        log_admin(f"Viewed manage users (filter={role_filter})")
        return render_template(
            "manage_users.html",
            users=users,
            current_filter=role_filter,
            username=session.get("username"),
        )

    except Exception as e:
        flash(f"Error loading users: {str(e)}", "error")
        return render_template(
            "manage_users.html",
            users=[],
            current_filter="all",
            username=session.get("username"),
        )
    finally:
        close_db_connection(conn)


@app.route("/add_user", methods=["GET", "POST"])
def add_user():
    """Admin page to create a new user (admin/teacher/student)."""
    if not login_required():
        return redirect("/login")

    if session.get("role") != "admin":
        flash("Access denied. Admin only.", "error")
        return redirect("/student_dashboard")

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        role = request.form.get("role", "student").strip()

        if not username or not email or not password or not role:
            flash("All fields are required", "error")
            return render_template("add_user.html", username=session.get("username"))

        if len(username) < 3:
            flash("Username must be at least 3 characters", "error")
            return render_template("add_user.html", username=session.get("username"))

        if not validate_email(email):
            flash("Invalid email format", "error")
            return render_template("add_user.html", username=session.get("username"))

        if not validate_password(password):
            flash("Password must be at least 6 characters", "error")
            return render_template("add_user.html", username=session.get("username"))

        if role not in ["admin", "teacher", "student"]:
            flash("Invalid role selected", "error")
            return render_template("add_user.html", username=session.get("username"))

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT id FROM users WHERE username=?", (username,))
            if cursor.fetchone():
                flash("Username already exists", "error")
                return render_template(
                    "add_user.html", username=session.get("username")
                )

            cursor.execute("SELECT id FROM users WHERE email=?", (email,))
            if cursor.fetchone():
                flash("Email already exists", "error")
                return render_template(
                    "add_user.html", username=session.get("username")
                )

            hashed_password = generate_password_hash(password)
            cursor.execute(
                """
                INSERT INTO users(username, email, password, role, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (username, email, hashed_password, role, datetime.now().isoformat()),
            )
            new_user_id = cursor.lastrowid

            cursor.execute(
                "INSERT INTO admin_logs(admin_id, action, created_at) VALUES (?, ?, ?)",
                (
                    session.get("user_id"),
                    f"Created user {username} (ID: {new_user_id}, Role: {role})",
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()

            flash(f"User '{username}' created successfully", "success")
            return redirect("/manage_users")
        except sqlite3.IntegrityError as e:
            flash(f"Database error: {str(e)}", "error")
            return render_template("add_user.html", username=session.get("username"))
        except sqlite3.Error as e:
            flash("Error creating user. Please try again.", "error")
            print(f"Add user error: {e}")
            return render_template("add_user.html", username=session.get("username"))
        finally:
            close_db_connection(conn)

    log_admin("Viewed add user form")
    return render_template("add_user.html", username=session.get("username"))


@app.route("/edit_user/<int:user_id>", methods=["GET", "POST"])
def edit_user(user_id):
    """Admin page to edit a specific user"""
    if not login_required():
        return redirect("/login")

    if session.get("role") != "admin":
        flash("Access denied. Admin only.", "error")
        return redirect("/student_dashboard")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Get user details
        cursor.execute(
            "SELECT id, username, email, role, created_at FROM users WHERE id=?",
            (user_id,),
        )
        user = cursor.fetchone()

        if not user:
            flash("User not found", "error")
            return redirect("/manage_users")

        if request.method == "POST":
            new_username = request.form.get("username", "").strip()
            new_email = request.form.get("email", "").strip()
            new_password = request.form.get("password", "").strip()

            # Validation
            if not new_username:
                flash("Username cannot be empty", "error")
                return render_template(
                    "edit_user.html", user=user, username=session.get("username")
                )

            if not new_email or not validate_email(new_email):
                flash("Invalid email format", "error")
                return render_template(
                    "edit_user.html", user=user, username=session.get("username")
                )

            try:
                # Check if username already exists (exclude current user)
                cursor.execute(
                    "SELECT id FROM users WHERE username=? AND id!=?",
                    (new_username, user_id),
                )
                if cursor.fetchone():
                    flash("Username already exists", "error")
                    return render_template(
                        "edit_user.html", user=user, username=session.get("username")
                    )

                # Check if email already exists (exclude current user)
                cursor.execute(
                    "SELECT id FROM users WHERE email=? AND id!=?", (new_email, user_id)
                )
                if cursor.fetchone():
                    flash("Email already exists", "error")
                    return render_template(
                        "edit_user.html", user=user, username=session.get("username")
                    )

                # Update username and email
                if new_password and len(new_password) >= 6:
                    # Update with new password
                    hashed_password = generate_password_hash(new_password)
                    cursor.execute(
                        "UPDATE users SET username=?, email=?, password=? WHERE id=?",
                        (new_username, new_email, hashed_password, user_id),
                    )
                    flash("User updated successfully (password changed)", "success")
                else:
                    # Update without password change
                    cursor.execute(
                        "UPDATE users SET username=?, email=? WHERE id=?",
                        (new_username, new_email, user_id),
                    )
                    if new_password and len(new_password) < 6:
                        flash(
                            "User updated (password not changed - minimum 6 characters required)",
                            "warning",
                        )
                    else:
                        flash("User updated successfully", "success")

                conn.commit()

                # Log this action
                cursor.execute(
                    "INSERT INTO admin_logs(admin_id, action) VALUES (?, ?)",
                    (
                        session.get("user_id"),
                        f"Edited user {new_username} (ID: {user_id})",
                    ),
                )
                conn.commit()

                return redirect("/manage_users")

            except sqlite3.IntegrityError as e:
                flash(f"Database error: {str(e)}", "error")
                return render_template(
                    "edit_user.html", user=user, username=session.get("username")
                )

        return render_template(
            "edit_user.html", user=user, username=session.get("username")
        )

    except Exception as e:
        flash(f"Error: {str(e)}", "error")
        return redirect("/manage_users")
    finally:
        close_db_connection(conn)


@app.route("/delete_user/<int:user_id>", methods=["POST"])
def delete_user(user_id):
    """Admin function to delete a user"""
    if not login_required():
        return redirect("/login")

    if session.get("role") != "admin":
        flash("Access denied. Admin only.", "error")
        return redirect("/student_dashboard")

    # Prevent admin from deleting themselves
    if user_id == session.get("user_id"):
        flash("You cannot delete your own account", "error")
        return redirect("/manage_users")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Get user info before deletion
        cursor.execute("SELECT username FROM users WHERE id=?", (user_id,))
        user = cursor.fetchone()

        if not user:
            flash("User not found", "error")
            return redirect("/manage_users")

        # Delete user (cascade delete should handle related records)
        cursor.execute("DELETE FROM users WHERE id=?", (user_id,))
        conn.commit()

        # Log this action
        cursor.execute(
            "INSERT INTO admin_logs(admin_id, action) VALUES (?, ?)",
            (session.get("user_id"), f"Deleted user {user[0]} (ID: {user_id})"),
        )
        conn.commit()

        flash(f"User '{user[0]}' deleted successfully", "success")
        return redirect("/manage_users")

    except Exception as e:
        flash(f"Error deleting user: {str(e)}", "error")
        return redirect("/manage_users")
    finally:
        close_db_connection(conn)


@app.route("/remove_teacher_restriction/<int:user_id>", methods=["POST"])
def remove_teacher_restriction(user_id):
    """Admin function to remove 24-hour restriction for a teacher"""
    if not login_required():
        return redirect("/login")

    if session.get("role") != "admin":
        flash("Access denied. Admin only.", "error")
        return redirect("/student_dashboard")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if user is a teacher
        cursor.execute("SELECT username, role FROM users WHERE id=?", (user_id,))
        user = cursor.fetchone()

        if not user:
            flash("User not found", "error")
            return redirect("/manage_users")

        if user[1] != "teacher":
            flash("Only teachers have time restrictions", "warning")
            return redirect("/manage_users")

        # Set created_at to 24+ hours ago to bypass restriction
        new_created_at = (datetime.now() - timedelta(hours=25)).isoformat()
        cursor.execute(
            "UPDATE users SET created_at=? WHERE id=?", (new_created_at, user_id)
        )
        conn.commit()

        # Log this action
        cursor.execute(
            "INSERT INTO admin_logs(admin_id, action) VALUES (?, ?)",
            (
                session.get("user_id"),
                f"Removed 24-hour restriction for teacher {user[0]} (ID: {user_id})",
            ),
        )
        conn.commit()

        flash(f"24-hour restriction removed for teacher '{user[0]}'", "success")
        return redirect("/manage_users")

    except Exception as e:
        flash(f"Error removing restriction: {str(e)}", "error")
        return redirect("/manage_users")
    finally:
        close_db_connection(conn)


# ================= QUESTIONS =================


@app.route("/manage_topics", methods=["GET", "POST"])
def manage_topics():
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    try:
        ensure_topic_tables()
    except Exception as e:
        print(f"ensure_topic_tables failed: {e}")

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()

        if not name:
            flash("Topic name is required", "error")
            return redirect("/manage_topics")

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO topics(name, description, created_by, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    name,
                    description,
                    session.get("user_id"),
                    datetime.now().isoformat(),
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()
            if session.get("role") == "teacher":
                log_teacher(f"Created topic '{name}'")
            flash("Topic created successfully", "success")
            return redirect("/manage_topics")
        except sqlite3.IntegrityError:
            flash("Topic name already exists", "error")
            return redirect("/manage_topics")
        finally:
            close_db_connection(conn)

    topics_data = []
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            SELECT topics.id,
                   topics.name,
                   topics.description,
                   topics.created_at,
                   topics.updated_at,
                   users.username AS created_by_name,
                   COUNT(topic_questions.question_id) AS question_count
            FROM topics
            LEFT JOIN users ON users.id = topics.created_by
            LEFT JOIN topic_questions ON topic_questions.topic_id = topics.id
            GROUP BY topics.id, topics.name, topics.description, topics.created_at, topics.updated_at, users.username
            ORDER BY topics.updated_at DESC, topics.name
            """
        )
        rows = cursor.fetchall()
        topics_data = [
            {
                "id": row["id"],
                "name": row["name"],
                "description": row["description"],
                "created_by_name": row["created_by_name"] or "System",
                "question_count": row["question_count"],
                "updated_at": format_display_datetime(row["updated_at"]),
                "practice_url": f"/start_quiz?topic_id={row['id']}",
            }
            for row in rows
        ]
    finally:
        close_db_connection(conn)

    return render_template(
        "manage_topics.html",
        topics=topics_data,
        username=session.get("username"),
        can_modify_questions=can_modify_questions(),
    )


@app.route("/manage_topics/<int:topic_id>", methods=["GET", "POST"])
def edit_topic(topic_id):
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    try:
        ensure_topic_tables()
    except Exception as e:
        print(f"ensure_topic_tables failed: {e}")

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            SELECT topics.id,
                   topics.name,
                   topics.description,
                   topics.updated_at,
                   users.username AS created_by_name
            FROM topics
            LEFT JOIN users ON users.id = topics.created_by
            WHERE topics.id=?
            """,
            (topic_id,),
        )
        topic = cursor.fetchone()
        if not topic:
            flash("Topic not found", "error")
            return redirect("/manage_topics")

        if request.method == "POST":
            name = request.form.get("name", "").strip()
            description = request.form.get("description", "").strip()

            if not name:
                flash("Topic name is required", "error")
                return redirect(f"/manage_topics/{topic_id}")

            try:
                cursor.execute(
                    """
                    UPDATE topics
                    SET name=?, description=?, updated_at=?
                    WHERE id=?
                    """,
                    (name, description, datetime.now().isoformat(), topic_id),
                )
                conn.commit()
                if session.get("role") == "teacher":
                    log_teacher(f"Updated topic '{name}'")
                flash("Topic updated successfully", "success")
                return redirect(f"/manage_topics/{topic_id}")
            except sqlite3.IntegrityError:
                flash("Topic name already exists", "error")
                return redirect(f"/manage_topics/{topic_id}")

        cursor.execute(
            """
            SELECT questions.id,
                   questions.question,
                   questions.option1,
                   questions.option2,
                   questions.option3,
                   questions.option4,
                   questions.correct_answer,
                   questions.difficulty
            FROM topic_questions
            JOIN questions ON questions.id = topic_questions.question_id
            WHERE topic_questions.topic_id=?
            ORDER BY topic_questions.id ASC
            """,
            (topic_id,),
        )
        topic_questions = cursor.fetchall()

        cursor.execute(
            """
            SELECT id, question, difficulty
            FROM questions
            WHERE id NOT IN (
                SELECT question_id FROM topic_questions WHERE topic_id=?
            )
            ORDER BY id DESC
            LIMIT 200
            """,
            (topic_id,),
        )
        available_questions = cursor.fetchall()

        topic_data = {
            "id": topic["id"],
            "name": topic["name"],
            "description": topic["description"],
            "updated_at": format_display_datetime(topic["updated_at"]),
            "created_by_name": topic["created_by_name"] or "System",
        }
        linked_questions = [
            {
                "id": row["id"],
                "question": row["question"],
                "option1": row["option1"],
                "option2": row["option2"],
                "option3": row["option3"],
                "option4": row["option4"],
                "correct_answer": row["correct_answer"],
                "difficulty": row["difficulty"],
            }
            for row in topic_questions
        ]
        selectable_questions = [
            {
                "id": row["id"],
                "question": row["question"],
                "difficulty": row["difficulty"],
            }
            for row in available_questions
        ]
    finally:
        close_db_connection(conn)

    return render_template(
        "edit_topic.html",
        topic=topic_data,
        topic_questions=linked_questions,
        available_questions=selectable_questions,
        can_modify_questions=can_modify_questions(),
    )


@app.route("/manage_topics/<int:topic_id>/delete", methods=["POST"])
def delete_topic(topic_id):
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM topics WHERE id=?", (topic_id,))
        topic = cursor.fetchone()
        if not topic:
            flash("Topic not found", "error")
            return redirect("/manage_topics")

        cursor.execute("DELETE FROM topic_questions WHERE topic_id=?", (topic_id,))
        cursor.execute("DELETE FROM topics WHERE id=?", (topic_id,))
        conn.commit()
        if session.get("role") == "teacher":
            log_teacher(f"Deleted topic '{topic['name']}'")
        flash("Topic deleted successfully", "success")
        return redirect("/manage_topics")
    finally:
        close_db_connection(conn)


@app.route("/manage_topics/<int:topic_id>/add-existing-question", methods=["POST"])
def add_existing_question_to_topic(topic_id):
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    question_id = request.form.get("question_id", "").strip()
    if not question_id.isdigit():
        flash("Select a valid question", "error")
        return redirect(f"/manage_topics/{topic_id}")

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM topics WHERE id=?", (topic_id,))
        topic = cursor.fetchone()
        if not topic:
            flash("Topic not found", "error")
            return redirect("/manage_topics")

        cursor.execute("SELECT id FROM questions WHERE id=?", (int(question_id),))
        if not cursor.fetchone():
            flash("Question not found", "error")
            return redirect(f"/manage_topics/{topic_id}")

        cursor.execute(
            """
            INSERT INTO topic_questions(topic_id, question_id, created_at)
            VALUES (?, ?, ?)
            """,
            (topic_id, int(question_id), datetime.now().isoformat()),
        )
        cursor.execute(
            "UPDATE topics SET updated_at=? WHERE id=?",
            (datetime.now().isoformat(), topic_id),
        )
        conn.commit()
        if session.get("role") == "teacher":
            log_teacher(
                f"Linked question {question_id} to topic '{topic['name']}'",
                int(question_id),
            )
        flash("Question added to topic", "success")
    except sqlite3.IntegrityError:
        flash("That question is already linked to this topic", "warning")
    finally:
        close_db_connection(conn)

    return redirect(f"/manage_topics/{topic_id}")


@app.route("/manage_topics/<int:topic_id>/remove-question/<int:question_id>", methods=["POST"])
def remove_question_from_topic(topic_id, question_id):
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "DELETE FROM topic_questions WHERE topic_id=? AND question_id=?",
            (topic_id, question_id),
        )
        cursor.execute(
            "UPDATE topics SET updated_at=? WHERE id=?",
            (datetime.now().isoformat(), topic_id),
        )
        conn.commit()
        if session.get("role") == "teacher":
            log_teacher(
                f"Removed question {question_id} from topic {topic_id}",
                question_id,
            )
        flash("Question removed from topic", "success")
    finally:
        close_db_connection(conn)

    return redirect(f"/manage_topics/{topic_id}")


@app.route("/manage_topics/<int:topic_id>/add-question", methods=["POST"])
def add_topic_question(topic_id):
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    if not can_modify_questions():
        flash(
            "Teachers cannot add questions for the first 24 hours after signup",
            "error",
        )
        return redirect(f"/manage_topics/{topic_id}")

    question = request.form.get("question", "").strip()
    option1 = request.form.get("option1", "").strip()
    option2 = request.form.get("option2", "").strip()
    option3 = request.form.get("option3", "").strip()
    option4 = request.form.get("option4", "").strip()
    correct = request.form.get("correct_answer", "").strip()
    difficulty = request.form.get("difficulty", "easy").strip().lower()

    if not all([question, option1, option2, option3, option4, correct]):
        flash("All question fields are required", "error")
        return redirect(f"/manage_topics/{topic_id}")

    if correct not in [option1, option2, option3, option4]:
        flash("Correct answer must be one of the options", "error")
        return redirect(f"/manage_topics/{topic_id}")

    if difficulty not in ["easy", "medium", "hard"]:
        flash("Invalid difficulty level", "error")
        return redirect(f"/manage_topics/{topic_id}")

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM topics WHERE id=?", (topic_id,))
        topic = cursor.fetchone()
        if not topic:
            flash("Topic not found", "error")
            return redirect("/manage_topics")

        cursor.execute(
            """
            INSERT INTO questions
            (question, option1, option2, option3, option4, correct_answer, difficulty, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                question,
                option1,
                option2,
                option3,
                option4,
                correct,
                difficulty,
                session.get("user_id"),
            ),
        )
        question_id = cursor.lastrowid

        cursor.execute(
            """
            INSERT INTO topic_questions(topic_id, question_id, created_at)
            VALUES (?, ?, ?)
            """,
            (topic_id, question_id, datetime.now().isoformat()),
        )
        cursor.execute(
            "UPDATE topics SET updated_at=? WHERE id=?",
            (datetime.now().isoformat(), topic_id),
        )

        if session.get("role") == "teacher":
            cursor.execute(
                """
                INSERT INTO teacher_logs(teacher_id, question_id, created_at)
                VALUES (?, ?, ?)
                """,
                (session.get("user_id"), question_id, datetime.now().isoformat()),
            )
            log_teacher(f"Added topic question to '{topic['name']}'", question_id)
        else:
            cursor.execute(
                """
                INSERT INTO admin_logs(admin_id, action, created_at)
                VALUES (?, ?, ?)
                """,
                (
                    session.get("user_id"),
                    f"Added question {question_id} to topic '{topic['name']}'",
                    datetime.now().isoformat(),
                ),
            )

        conn.commit()
        flash("Question created and added to topic", "success")
        return redirect(f"/manage_topics/{topic_id}")
    finally:
        close_db_connection(conn)


@app.route("/manage_topics/<int:topic_id>/questions/<int:question_id>/edit", methods=["GET", "POST"])
def edit_topic_question(topic_id, question_id):
    if not login_required() or not can_manage_topics():
        flash("Access denied", "error")
        return redirect(get_dashboard_route())

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, name FROM topics WHERE id=?", (topic_id,))
        topic = cursor.fetchone()
        if not topic:
            flash("Topic not found", "error")
            return redirect("/manage_topics")

        cursor.execute(
            """
            SELECT questions.id,
                   questions.question,
                   questions.option1,
                   questions.option2,
                   questions.option3,
                   questions.option4,
                   questions.correct_answer,
                   questions.difficulty
            FROM questions
            JOIN topic_questions ON topic_questions.question_id = questions.id
            WHERE topic_questions.topic_id=? AND questions.id=?
            """,
            (topic_id, question_id),
        )
        question_row = cursor.fetchone()
        if not question_row:
            flash("Question not found for this topic", "error")
            return redirect(f"/manage_topics/{topic_id}")

        if request.method == "POST":
            if not can_modify_questions():
                flash(
                    "Teachers cannot edit questions for the first 24 hours after signup",
                    "error",
                )
                return redirect(f"/manage_topics/{topic_id}")

            question = request.form.get("question", "").strip()
            option1 = request.form.get("option1", "").strip()
            option2 = request.form.get("option2", "").strip()
            option3 = request.form.get("option3", "").strip()
            option4 = request.form.get("option4", "").strip()
            correct = request.form.get("correct_answer", "").strip()
            difficulty = request.form.get("difficulty", "easy").strip().lower()

            if not all([question, option1, option2, option3, option4, correct]):
                flash("All question fields are required", "error")
                return redirect(
                    f"/manage_topics/{topic_id}/questions/{question_id}/edit"
                )

            if correct not in [option1, option2, option3, option4]:
                flash("Correct answer must be one of the options", "error")
                return redirect(
                    f"/manage_topics/{topic_id}/questions/{question_id}/edit"
                )

            if difficulty not in ["easy", "medium", "hard"]:
                flash("Invalid difficulty level", "error")
                return redirect(
                    f"/manage_topics/{topic_id}/questions/{question_id}/edit"
                )

            cursor.execute(
                """
                UPDATE questions
                SET question=?, option1=?, option2=?, option3=?, option4=?,
                    correct_answer=?, difficulty=?
                WHERE id=?
                """,
                (
                    question,
                    option1,
                    option2,
                    option3,
                    option4,
                    correct,
                    difficulty,
                    question_id,
                ),
            )
            cursor.execute(
                "UPDATE topics SET updated_at=? WHERE id=?",
                (datetime.now().isoformat(), topic_id),
            )
            conn.commit()

            if session.get("role") == "teacher":
                log_teacher(
                    f"Edited question {question_id} in topic '{topic['name']}'",
                    question_id,
                )

            flash("Question updated successfully", "success")
            return redirect(f"/manage_topics/{topic_id}")

        topic_data = {"id": topic["id"], "name": topic["name"]}
        question_data = {
            "id": question_row["id"],
            "question": question_row["question"],
            "option1": question_row["option1"],
            "option2": question_row["option2"],
            "option3": question_row["option3"],
            "option4": question_row["option4"],
            "correct_answer": question_row["correct_answer"],
            "difficulty": question_row["difficulty"],
        }
    finally:
        close_db_connection(conn)

    return render_template(
        "edit_topic_question.html",
        topic=topic_data,
        question=question_data,
        can_modify_questions=can_modify_questions(),
    )


@app.route("/add_question", methods=["GET", "POST"])
def add_question():
    if not login_required():
        return redirect("/login")

    try:
        ensure_activity_tables()
    except Exception as e:
        print(f"ensure_activity_tables failed: {e}")

    user_id = session.get("user_id")
    role = session.get("role")

    if role not in ["admin", "teacher"]:
        flash("Access denied", "error")
        return redirect("/student_dashboard")

    if role == "teacher" and not teacher_can_add(user_id):
        flash(
            "❌ Teachers cannot add questions for the first 24 hours after signup",
            "error",
        )
        return redirect("/teacher_dashboard")

    if request.method == "POST":
        question = request.form.get("question", "").strip()
        option1 = request.form.get("option1", "").strip()
        option2 = request.form.get("option2", "").strip()
        option3 = request.form.get("option3", "").strip()
        option4 = request.form.get("option4", "").strip()
        correct = request.form.get("correct", "").strip()
        difficulty = request.form.get("difficulty", "medium").strip()

        if not all([question, option1, option2, option3, option4, correct]):
            flash("All fields are required", "error")
            return render_template("add_question.html")

        if correct not in [option1, option2, option3, option4]:
            flash("Correct answer must be one of the options", "error")
            return render_template("add_question.html")

        if difficulty not in ["easy", "medium", "hard"]:
            flash("Invalid difficulty level", "error")
            return render_template("add_question.html")

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
            INSERT INTO questions
            (question, option1, option2, option3, option4, correct_answer, difficulty, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    question,
                    option1,
                    option2,
                    option3,
                    option4,
                    correct,
                    difficulty,
                    user_id,
                ),
            )

            question_id = cursor.lastrowid

            if role == "teacher":
                cursor.execute(
                    """
                INSERT INTO teacher_logs(teacher_id, question_id, created_at)
                VALUES (?, ?, ?)
                """,
                    (user_id, question_id, datetime.now().isoformat()),
                )
                # New, richer teacher activity log
                try:
                    cursor.execute(
                        """
                        INSERT INTO teacher_activity_logs(teacher_id, action, question_id, created_at)
                        VALUES (?, ?, ?, ?)
                        """,
                        (
                            user_id,
                            "Added Question",
                            question_id,
                            datetime.now().isoformat(),
                        ),
                    )
                except Exception as e:
                    print(f"Teacher activity log insert failed: {e}")
            else:
                cursor.execute(
                    """
                INSERT INTO admin_logs(admin_id, action, created_at)
                VALUES (?, ?, ?)
                """,
                    (user_id, "Added Question", datetime.now().isoformat()),
                )

            conn.commit()
            flash("Question added successfully!", "success")
            return redirect(
                "/admin_dashboard" if role == "admin" else "/teacher_dashboard"
            )

        except sqlite3.Error as e:
            flash("Error adding question. Please try again.", "error")
            print(f"Add question error: {e}")
            return render_template("add_question.html")
        finally:
            close_db_connection(conn)

    return render_template("add_question.html")


@app.route("/delete_question", methods=["GET", "POST"])
def delete_question():
    if not login_required() or session.get("role") != "admin":
        flash("Access denied", "error")
        return redirect("/student_dashboard")

    try:
        ensure_topic_tables()
    except Exception as e:
        print(f"ensure_topic_tables failed: {e}")

    if request.method == "POST":
        qid = request.form.get("qid", "").strip()

        if not qid or not qid.isdigit():
            flash("Invalid question ID", "error")
            return render_template("delete_question.html")

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("SELECT id FROM questions WHERE id=?", (qid,))
            if not cursor.fetchone():
                flash("Question not found", "error")
                return render_template("delete_question.html")

            cursor.execute("DELETE FROM topic_questions WHERE question_id=?", (qid,))
            cursor.execute("DELETE FROM questions WHERE id=?", (qid,))

            cursor.execute(
                """
            INSERT INTO admin_logs(admin_id, action, created_at)
            VALUES (?, ?, ?)
            """,
                (
                    session["user_id"],
                    f"Deleted Question {qid}",
                    datetime.now().isoformat(),
                ),
            )

            conn.commit()
            flash(f"Question {qid} deleted successfully!", "success")
            return redirect("/admin_dashboard")

        except sqlite3.Error as e:
            flash("Error deleting question. Please try again.", "error")
            print(f"Delete question error: {e}")
            return render_template("delete_question.html")
        finally:
            close_db_connection(conn)

    return render_template("delete_question.html")


# ================= QUIZ =================


@app.route("/start_quiz")
def start_quiz():
    if not login_required():
        return redirect("/login")

    topic_id_raw = request.args.get("topic_id", "").strip()
    topic_id = None
    if topic_id_raw:
        if not topic_id_raw.isdigit():
            flash("Selected topic is not valid.", "warning")
            return redirect("/topics")
        topic_id = int(topic_id_raw)

    topic_slug = request.args.get("topic", "").strip().lower()
    topic = None
    if topic_id is not None or topic_slug:
        topic = resolve_quiz_topic(
            topic_slug=topic_slug or None,
            topic_id=topic_id,
        )
        if not topic:
            flash("Selected topic is not available right now.", "warning")
            return redirect("/topics")

    # Ensure logging tables exist (safe no-op if already created)
    try:
        ensure_activity_tables()
    except Exception as e:
        print(f"ensure_activity_tables failed: {e}")

    clear_active_quiz_state(clear_last_session=True)
    session["score"] = 0
    session["count"] = 0
    session["answered_questions"] = []
    session["quiz_review_items"] = []
    if topic_id is not None:
        session["quiz_topic_id"] = topic_id
    else:
        session.pop("quiz_topic_id", None)
    if topic_slug:
        session["quiz_topic_slug"] = topic_slug
    else:
        session.pop("quiz_topic_slug", None)

    # Check if questions exist
    total_questions = count_questions(
        topic_slug=topic_slug or None,
        topic_id=topic_id,
    )

    if total_questions == 0:
        if topic:
            flash(
                f"No questions are available for {topic['name']} yet. Try another topic.",
                "warning",
            )
            return redirect("/topics")
        flash("❌ No questions available. Please try again later.", "error")
        return redirect("/student_dashboard")

    quiz_total_questions = min(5, total_questions)
    session["quiz_total_questions"] = quiz_total_questions

    # Get first random question
    q = get_random_question(
        topic_slug=topic_slug or None,
        topic_id=topic_id,
    )

    if not q:
        flash("❌ Error loading question", "error")
        return redirect("/student_dashboard")

    # Create quiz session log
    if session.get("role") == "student":
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO student_quiz_sessions(student_id, started_at, total_questions)
                VALUES (?, ?, ?)
                """,
                (
                    session.get("user_id"),
                    datetime.now().isoformat(),
                    quiz_total_questions,
                ),
            )
            session["quiz_session_id"] = cursor.lastrowid
            conn.commit()
        except Exception as e:
            print(f"Quiz session start log error: {e}")
        finally:
            close_db_connection(conn)

    session["answered_questions"].append(q[0])
    return render_template(
        "quiz.html",
        q=q,
        question_number=1,
        total_questions=quiz_total_questions,
        topic_name=topic["name"] if topic else None,
    )


@app.route("/cancel_quiz", methods=["POST"])
def cancel_quiz():
    if not login_required():
        return redirect("/login")

    quiz_session_id = session.get("quiz_session_id")

    if session.get("role") == "student" and quiz_session_id:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                DELETE FROM student_quiz_answers
                WHERE session_id=? AND student_id=?
                """,
                (quiz_session_id, session.get("user_id")),
            )
            cursor.execute(
                """
                DELETE FROM student_quiz_sessions
                WHERE id=? AND student_id=?
                """,
                (quiz_session_id, session.get("user_id")),
            )
            conn.commit()
        except Exception as e:
            print(f"Quiz cancel cleanup error: {e}")
        finally:
            close_db_connection(conn)

    clear_active_quiz_state(clear_last_session=True)
    flash("Quiz cancelled. You are back on the dashboard.", "warning")
    return redirect(get_dashboard_route())


@app.route("/submit_answer", methods=["POST"])
def submit_answer():
    if not login_required():
        return redirect("/login")

    qid = request.form.get("question_id", "").strip()
    answer = request.form.get("answer", "").strip()
    time_taken = request.form.get("time", "0").strip()

    if not qid or not qid.isdigit():
        flash("Invalid question", "error")
        return redirect("/start_quiz")

    # If no answer selected, treat it as a silent incorrect answer (do not flash or redirect)
    if not answer:
        # leave answer empty so comparison below marks it incorrect
        answer = ""

    try:
        time_taken = int(time_taken)
    except ValueError:
        time_taken = 0

    conn = get_db_connection()
    cursor = conn.cursor()
    topic_id = session.get("quiz_topic_id")
    topic_slug = session.get("quiz_topic_slug")
    quiz_total_questions = session.get("quiz_total_questions", 5)

    try:
        cursor.execute(
            "SELECT question, correct_answer FROM questions WHERE id=?", (qid,)
        )
        correct_data = cursor.fetchone()

        if not correct_data:
            flash("Question not found", "error")
            return redirect("/start_quiz")

        correct_answer = correct_data["correct_answer"]
        question_text = correct_data["question"]
        is_correct = 1 if answer == correct_answer else 0
        if is_correct:
            session["score"] = session.get("score", 0) + 1

        session["count"] = session.get("count", 0) + 1

        review_items = list(session.get("quiz_review_items", []))
        review_items.append(
            {
                "question_id": int(qid),
                "question": question_text,
                "selected_answer": answer.strip(),
                "display_answer": (
                    answer.strip() if answer and answer.strip() else "No answer selected"
                ),
                "correct_answer": correct_answer,
                "is_correct": bool(is_correct),
                "time_taken": time_taken,
            }
        )
        session["quiz_review_items"] = review_items

        cursor.execute(
            """
        INSERT INTO student_logs(student_id, question_id, time_taken, created_at)
        VALUES (?, ?, ?, ?)
        """,
            (session["user_id"], qid, time_taken, datetime.now().isoformat()),
        )

        # Rich answer logging (student dashboard requirement)
        quiz_session_id = session.get("quiz_session_id")
        if session.get("role") == "student" and quiz_session_id:
            try:
                cursor.execute(
                    """
                    INSERT INTO student_quiz_answers
                      (session_id, student_id, question_id, selected_answer, correct_answer, is_correct, time_taken, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        quiz_session_id,
                        session.get("user_id"),
                        int(qid),
                        answer,
                        correct_answer,
                        is_correct,
                        time_taken,
                        datetime.now().isoformat(),
                    ),
                )
            except Exception as e:
                print(f"Quiz answer log error: {e}")

        if session["count"] >= quiz_total_questions:
            finalize_quiz_attempt(cursor, quiz_session_id)
            conn.commit()
            return redirect("/result")

        answered = session.get("answered_questions", [])

        # Try to get a question not yet answered
        if answered:
            q = get_random_question(
                exclude_ids=answered,
                topic_slug=topic_slug,
                topic_id=topic_id,
            )
        else:
            q = get_random_question(topic_slug=topic_slug, topic_id=topic_id)

        if not q:
            finalize_quiz_attempt(cursor, quiz_session_id)
            conn.commit()
            return redirect("/result")

        if q:
            session["answered_questions"].append(q[0])
        else:
            flash("❌ No more questions available", "error")
            return redirect("/student_dashboard")

        conn.commit()
        topic = get_topic_config(topic_slug) if topic_slug else None
        return render_template(
            "quiz.html",
            q=q,
            question_number=session["count"] + 1,
            total_questions=quiz_total_questions,
            topic_name=topic["name"] if topic else None,
        )

    except sqlite3.Error as e:
        flash("Error processing answer", "error")
        print(f"Submit answer error: {e}")
        return redirect("/start_quiz")
    finally:
        close_db_connection(conn)


@app.route("/result")
def result():
    if not login_required():
        return redirect("/login")

    score = session.get("score", 0)
    total = session.get("quiz_total_questions", session.get("count", 0))
    review_items = list(
        session.get("last_quiz_review_items") or session.get("quiz_review_items") or []
    )
    correct_count = sum(1 for item in review_items if item.get("is_correct"))
    incorrect_count = len(review_items) - correct_count
    if review_items:
        score = correct_count
        if not total or total < len(review_items):
            total = len(review_items)

    quiz_session_id = session.get("quiz_session_id") or session.get(
        "last_quiz_session_id"
    )
    if session.get("role") == "student" and not review_items:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            session_row = None

            if quiz_session_id:
                cursor.execute(
                    """
                    UPDATE student_quiz_sessions
                    SET ended_at = COALESCE(ended_at, ?),
                        score = COALESCE(score, ?)
                    WHERE id=? AND student_id=?
                    """,
                    (
                        datetime.now().isoformat(),
                        score,
                        quiz_session_id,
                        session.get("user_id"),
                    ),
                )
                conn.commit()
                cursor.execute(
                    """
                    SELECT id, score, total_questions
                    FROM student_quiz_sessions
                    WHERE id=? AND student_id=?
                    """,
                    (quiz_session_id, session.get("user_id")),
                )
                session_row = cursor.fetchone()

            if not session_row:
                cursor.execute(
                    """
                    SELECT id, score, total_questions
                    FROM student_quiz_sessions
                    WHERE student_id=?
                    ORDER BY id DESC
                    LIMIT 1
                    """,
                    (session.get("user_id"),),
                )
                session_row = cursor.fetchone()

            if session_row:
                quiz_session_id = session_row["id"]
                session["last_quiz_session_id"] = quiz_session_id
                if session_row["score"] is not None:
                    score = session_row["score"]
                if session_row["total_questions"]:
                    total = session_row["total_questions"]

                cursor.execute(
                    """
                    SELECT
                        student_quiz_answers.question_id,
                        questions.question,
                        student_quiz_answers.selected_answer,
                        student_quiz_answers.correct_answer,
                        student_quiz_answers.is_correct,
                        student_quiz_answers.time_taken
                    FROM student_quiz_answers
                    JOIN questions ON questions.id = student_quiz_answers.question_id
                    WHERE student_quiz_answers.session_id=? AND student_quiz_answers.student_id=?
                    ORDER BY student_quiz_answers.id ASC
                    """,
                    (quiz_session_id, session.get("user_id")),
                )
                rows = cursor.fetchall()
                review_items = [
                    {
                        "question_id": row["question_id"],
                        "question": row["question"],
                        "selected_answer": (
                            row["selected_answer"].strip()
                            if row["selected_answer"]
                            else ""
                        ),
                        "display_answer": (
                            row["selected_answer"].strip()
                            if row["selected_answer"] and row["selected_answer"].strip()
                            else "No answer selected"
                        ),
                        "correct_answer": row["correct_answer"],
                        "is_correct": bool(row["is_correct"]),
                        "time_taken": row["time_taken"] or 0,
                    }
                    for row in rows
                ]
                session["last_quiz_review_items"] = review_items
                correct_count = sum(1 for item in review_items if item["is_correct"])
                incorrect_count = len(review_items) - correct_count
                if review_items:
                    score = correct_count
                    if not total or total < len(review_items):
                        total = len(review_items)
        except Exception as e:
            print(f"Result review load error: {e}")
        finally:
            close_db_connection(conn)

    return render_template(
        "result.html",
        score=score,
        total=total,
        review_items=review_items,
        correct_count=correct_count,
        incorrect_count=incorrect_count,
    )


# ================= LEADERBOARD =================


@app.route("/leaderboard")
def leaderboard():
    if not login_required():
        return redirect("/login")

    if session.get("role") == "admin":
        log_admin("Viewed leaderboard")
    elif session.get("role") == "teacher":
        log_teacher("Viewed leaderboard")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
        SELECT users.username, MAX(results.score) as best_score, COUNT(results.id) as attempts
        FROM results
        JOIN users ON users.id = results.user_id
        WHERE users.role='student'
        GROUP BY users.username
        ORDER BY best_score DESC, attempts DESC
        LIMIT 100
        """)

        data = cursor.fetchall()
        return render_template("leaderboard.html", data=data)
    finally:
        close_db_connection(conn)


# ================= LOGS =================


@app.route("/admin_logs")
def admin_logs():
    if not login_required():
        return redirect("/login")

    try:
        ensure_activity_tables()
    except Exception as e:
        print(f"ensure_activity_tables failed: {e}")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            """
            SELECT admin_logs.id, users.username, admin_logs.action, admin_logs.created_at
            FROM admin_logs
            JOIN users ON users.id = admin_logs.admin_id
            ORDER BY admin_logs.id DESC
            LIMIT 200
            """
        )
        data = cursor.fetchall()
        return render_template("admin_logs.html", data=data)
    finally:
        close_db_connection(conn)


@app.route("/teacher_logs")
def teacher_logs():
    if not login_required():
        return redirect("/login")

    try:
        ensure_activity_tables()
    except Exception as e:
        print(f"ensure_activity_tables failed: {e}")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        if session.get("role") == "admin":
            log_admin("Viewed teacher logs")
        elif session.get("role") == "teacher":
            log_teacher("Viewed teacher logs")

        # Admin can see all teacher logs; teacher can see their own.
        params = []
        where = ""
        if session.get("role") == "teacher":
            where = "WHERE teacher_activity_logs.teacher_id = ?"
            params = [session.get("user_id")]

        cursor.execute(
            f"""
            SELECT teacher_activity_logs.id,
                   users.username,
                   teacher_activity_logs.action,
                   teacher_activity_logs.question_id,
                   questions.question,
                   teacher_activity_logs.created_at
            FROM teacher_activity_logs
            JOIN users ON users.id = teacher_activity_logs.teacher_id
            LEFT JOIN questions ON questions.id = teacher_activity_logs.question_id
            {where}
            ORDER BY teacher_activity_logs.created_at DESC
            LIMIT 200
            """,
            params,
        )
        data = cursor.fetchall()
        return render_template("teacher_logs.html", data=data)
    finally:
        close_db_connection(conn)


@app.route("/student_logs")
def student_logs():
    if not login_required():
        return redirect("/login")

    try:
        ensure_activity_tables()
    except Exception as e:
        print(f"ensure_activity_tables failed: {e}")

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        if session.get("role") == "admin":
            log_admin("Viewed student logs")

        sess_params = []
        sess_where = ""

        if session.get("role") == "student":
            sess_where = "WHERE student_quiz_sessions.student_id = ?"
            sess_params = [session.get("user_id")]

        cursor.execute(
            f"""
            SELECT student_quiz_sessions.id,
                   student_quiz_sessions.student_id,
                   users.username,
                   student_quiz_sessions.started_at,
                   student_quiz_sessions.ended_at,
                   student_quiz_sessions.score,
                   student_quiz_sessions.total_questions
            FROM student_quiz_sessions
            JOIN users ON users.id = student_quiz_sessions.student_id
            {sess_where}
            ORDER BY student_quiz_sessions.started_at DESC
            LIMIT 50
            """,
            sess_params,
        )
        session_rows = cursor.fetchall()

        session_ids = [row["id"] for row in session_rows]
        answers_by_session = {}

        if session_ids:
            placeholders = ",".join(["?" for _ in session_ids])
            cursor.execute(
                f"""
                SELECT student_quiz_answers.session_id,
                       student_quiz_answers.question_id,
                       questions.question,
                       student_quiz_answers.selected_answer,
                       student_quiz_answers.correct_answer,
                       student_quiz_answers.is_correct,
                       student_quiz_answers.time_taken,
                       student_quiz_answers.created_at
                FROM student_quiz_answers
                JOIN questions ON questions.id = student_quiz_answers.question_id
                WHERE student_quiz_answers.session_id IN ({placeholders})
                ORDER BY student_quiz_answers.session_id DESC, student_quiz_answers.id ASC
                """,
                session_ids,
            )
            answer_rows = cursor.fetchall()

            for row in answer_rows:
                answers_by_session.setdefault(row["session_id"], []).append(
                    {
                        "question_id": row["question_id"],
                        "question": row["question"],
                        "selected_answer": (
                            row["selected_answer"].strip()
                            if row["selected_answer"]
                            else ""
                        ),
                        "display_answer": (
                            row["selected_answer"].strip()
                            if row["selected_answer"] and row["selected_answer"].strip()
                            else "No answer selected"
                        ),
                        "correct_answer": row["correct_answer"],
                        "is_correct": bool(row["is_correct"]),
                        "time_taken": row["time_taken"] or 0,
                        "answered_at": format_display_datetime(row["created_at"]),
                    }
                )

        quiz_history = []
        for row in session_rows:
            review_items = answers_by_session.get(row["id"], [])

            # Hide legacy empty sessions that have no useful review data.
            if not review_items and row["score"] is None and not row["ended_at"]:
                continue

            correct_count = sum(1 for item in review_items if item["is_correct"])
            incorrect_count = len(review_items) - correct_count
            total_questions = row["total_questions"] or len(review_items)
            score = row["score"] if row["score"] is not None else correct_count

            quiz_history.append(
                {
                    "id": row["id"],
                    "student_name": row["username"],
                    "started_at": format_display_datetime(row["started_at"]),
                    "ended_at": format_display_datetime(row["ended_at"]),
                    "score": score,
                    "total_questions": total_questions,
                    "correct_count": correct_count,
                    "incorrect_count": incorrect_count,
                    "review_items": review_items,
                    "has_review": len(review_items) > 0,
                }
            )

        return render_template("student_logs.html", quiz_history=quiz_history)
    finally:
        close_db_connection(conn)


# ================= ERROR HANDLERS =================


@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404


@app.errorhandler(500)
def server_error(error):
    print(f"Server error: {error}")
    return render_template("500.html"), 500


# ================= RUN =================

if __name__ == "__main__":
    try:
        ensure_activity_tables()
        ensure_topic_tables()
    except Exception as e:
        print(f"Activity/topic table setup failed: {e}")
    app.run(debug=True)
