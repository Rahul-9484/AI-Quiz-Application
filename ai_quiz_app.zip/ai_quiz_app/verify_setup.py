#!/usr/bin/env python3
"""
Verification script for AI Quiz App setup
Run: python verify_setup.py
"""

import os
import sqlite3
import sys
from datetime import datetime

DATABASE = "database.db"

# Ensure Windows consoles that default to cp1252 don't crash on emoji output.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def check_database():
    """Check if database exists and has tables"""
    print("\n📊 CHECKING DATABASE...")
    print("=" * 60)

    if not os.path.exists(DATABASE):
        print("❌ database.db NOT FOUND")
        print("   Run: python init_db.py")
        return False

    print("✅ database.db found")

    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Check tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()

        required_tables = [
            "users",
            "questions",
            "results",
            "admin_logs",
            "teacher_logs",
            "student_logs",
        ]

        print(f"\n📋 Tables ({len(tables)}/{len(required_tables)}):")
        for table in tables:
            cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
            count = cursor.fetchone()[0]
            status = "✅" if table[0] in required_tables else "⚠️"
            print(f"   {status} {table[0]}: {count} records")

        # Check admin user
        cursor.execute("SELECT COUNT(*) FROM users WHERE role='admin'")
        admin_count = cursor.fetchone()[0]
        print(f"\n👤 Admin Users: {admin_count}")
        if admin_count > 0:
            print("   ✅ Admin user exists")
        else:
            print("   ❌ No admin user found")

        # Check questions
        cursor.execute("SELECT COUNT(*) FROM questions")
        q_count = cursor.fetchone()[0]
        print(f"\n❓ Questions: {q_count}")
        if q_count > 0:
            print("   ✅ Questions available")
            cursor.execute("""
            SELECT difficulty, COUNT(*)
            FROM questions
            GROUP BY difficulty
            """)
            for diff, count in cursor.fetchall():
                print(f"      - {diff}: {count}")
        else:
            print("   ⚠️  No questions yet. Run: python add_questions.py")

        conn.close()
        return True

    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def check_dependencies():
    """Check if required packages are installed"""
    print("\n📦 CHECKING DEPENDENCIES...")
    print("=" * 60)

    required = ["flask", "werkzeug", "sqlite3"]

    for package in required:
        try:
            if package == "sqlite3":
                import sqlite3
            elif package == "flask":
                import flask
            elif package == "werkzeug":
                import werkzeug
            print(f"✅ {package} installed")
        except ImportError:
            print(f"❌ {package} NOT installed")
            print(f"   Run: pip install {package}")
            return False

    return True


def check_files():
    """Check if all required files exist"""
    print("\n📁 CHECKING FILES...")
    print("=" * 60)

    required_files = [
        "app.py",
        "init_db.py",
        "templates/login.html",
        "templates/signup.html",
        "templates/quiz.html",
        "templates/admin_dashboard.html",
        "templates/teacher_dashboard.html",
        "templates/student_dashboard.html",
    ]

    all_exist = True
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file}")
        else:
            print(f"❌ {file} NOT FOUND")
            all_exist = False

    return all_exist


def main():
    print("\n" + "=" * 60)
    print("🎓 AI QUIZ APP - SETUP VERIFICATION")
    print("=" * 60)

    checks = [
        ("Files", check_files()),
        ("Dependencies", check_dependencies()),
        ("Database", check_database()),
    ]

    print("\n" + "=" * 60)
    print("📋 VERIFICATION SUMMARY")
    print("=" * 60)

    all_passed = True
    for check_name, result in checks:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {check_name}")
        if not result:
            all_passed = False

    print("=" * 60)

    if all_passed:
        print("\n✨ ALL CHECKS PASSED!")
        print("\n🚀 Ready to run: python app.py")
        print("   Then visit: http://127.0.0.1:5000/login")
    else:
        print("\n⚠️  SOME CHECKS FAILED")
        print("\nFix the issues above and run again:")
        print("   python verify_setup.py")

    print("=" * 60 + "\n")

    return all_passed


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
