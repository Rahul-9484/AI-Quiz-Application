import os
import sqlite3
import sys
from datetime import datetime

from werkzeug.security import generate_password_hash

# Ensure Windows consoles that default to cp1252 don't crash on emoji output.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# Get the directory where this script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(script_dir, "database.db")

print("=" * 60)
print("🗄️  DATABASE INITIALIZATION SCRIPT")
print("=" * 60)

# Delete old database if it exists
if os.path.exists(db_path):
    print(f"\n⚠️  Found existing database at {db_path}")
    print("🔄 Recreating database...")
    try:
        os.remove(db_path)
        print("✅ Old database removed")
    except Exception as e:
        print(f"❌ Error removing old database: {e}")
        exit(1)

# Create connection
try:
    print(f"\n📝 Creating database at: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    print("✅ Connection established")
except Exception as e:
    print(f"❌ Error connecting to database: {e}")
    exit(1)

# Create tables
print("\n📋 Creating tables...")

try:
    # USERS TABLE
    print("  • Creating users table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'teacher', 'student')),
    created_at TEXT NOT NULL
    )
    """)
    print("    ✅ Users table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # QUESTIONS TABLE
    print("  • Creating questions table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS questions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    option1 TEXT NOT NULL,
    option2 TEXT NOT NULL,
    option3 TEXT NOT NULL,
    option4 TEXT NOT NULL,
    correct_answer TEXT NOT NULL,
    difficulty TEXT NOT NULL CHECK(difficulty IN ('easy', 'medium', 'hard')),
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)
    print("    ✅ Questions table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # RESULTS TABLE
    print("  • Creating results table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS results(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
    )
    """)
    print("    ✅ Results table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # ADMIN LOGS TABLE
    print("  • Creating admin_logs table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS admin_logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(admin_id) REFERENCES users(id)
    )
    """)
    print("    ✅ Admin logs table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # TEACHER LOGS TABLE
    print("  • Creating teacher_logs table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS teacher_logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    teacher_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(teacher_id) REFERENCES users(id),
    FOREIGN KEY(question_id) REFERENCES questions(id)
    )
    """)
    print("    ✅ Teacher logs table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # TEACHER ACTIVITY LOGS (richer)
    print("  • Creating teacher_activity_logs table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS teacher_activity_logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    teacher_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    question_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(teacher_id) REFERENCES users(id),
    FOREIGN KEY(question_id) REFERENCES questions(id)
    )
    """)
    print("    ✅ Teacher activity logs table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # STUDENT LOGS TABLE
    print("  • Creating student_logs table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    time_taken INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(student_id) REFERENCES users(id),
    FOREIGN KEY(question_id) REFERENCES questions(id)
    )
    """)
    print("    ✅ Student logs table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # STUDENT QUIZ SESSIONS (start/end)
    print("  • Creating student_quiz_sessions table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_quiz_sessions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    score INTEGER,
    total_questions INTEGER DEFAULT 5,
    FOREIGN KEY(student_id) REFERENCES users(id)
    )
    """)
    print("    ✅ Student quiz sessions table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

try:
    # STUDENT QUIZ ANSWERS (per question)
    print("  • Creating student_quiz_answers table...")
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_quiz_answers(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    selected_answer TEXT NOT NULL,
    correct_answer TEXT NOT NULL,
    is_correct INTEGER NOT NULL,
    time_taken INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(session_id) REFERENCES student_quiz_sessions(id),
    FOREIGN KEY(student_id) REFERENCES users(id),
    FOREIGN KEY(question_id) REFERENCES questions(id)
    )
    """)
    print("    ✅ Student quiz answers table created")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

# Insert default admin user
print("\n👤 Creating default admin user...")

try:
    admin_password = generate_password_hash("admin123")
    cursor.execute(
        """
    INSERT INTO users(username, email, password, role, created_at)
    VALUES (?, ?, ?, ?, ?)
    """,
        (
            "Admin",
            "admin@mail.com",
            admin_password,
            "admin",
            datetime.now().isoformat(),
        ),
    )
    print("    ✅ Admin user created")
except sqlite3.IntegrityError:
    print("    ⚠️  Admin user already exists (skipped)")
except Exception as e:
    print(f"    ❌ Error: {e}")
    conn.close()
    exit(1)

# Commit and close
try:
    conn.commit()
    print("\n✅ Database committed successfully")
except Exception as e:
    print(f"❌ Error committing: {e}")
    conn.close()
    exit(1)

try:
    conn.close()
    print("✅ Connection closed")
except Exception as e:
    print(f"❌ Error closing connection: {e}")
    exit(1)

# Verify database
print("\n🔍 Verifying database...")

try:
    verify_conn = sqlite3.connect(db_path)
    verify_cursor = verify_conn.cursor()

    # Check all tables exist
    tables = [
        "users",
        "questions",
        "results",
        "admin_logs",
        "teacher_logs",
        "student_logs",
    ]

    for table in tables:
        verify_cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = verify_cursor.fetchone()[0]
        print(f"  ✅ {table}: {count} records")

    verify_conn.close()
    print("\n✅ Database verification successful!")

except Exception as e:
    print(f"❌ Verification failed: {e}")
    exit(1)

# Print success message
print("\n" + "=" * 60)
print("🎉 DATABASE INITIALIZATION COMPLETE!")
print("=" * 60)
print("\n📋 Default Admin Credentials:")
print("   Email: admin@mail.com")
print("   Password: admin123")
print("\n📍 Database location:")
print(f"   {db_path}")
print("\n🚀 Ready to run the app!")
print("\nNext steps:")
print("  1. Run: python app.py")
print("  2. Visit: http://127.0.0.1:5000/login")
print("  3. Login with credentials above")
print("\n" + "=" * 60)
