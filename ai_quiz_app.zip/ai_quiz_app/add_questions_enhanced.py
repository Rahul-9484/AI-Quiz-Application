#!/usr/bin/env python3
"""
Enhanced script to add comprehensive questions with:
- Cnacle Quiz (Practice Mode - no points gained/lost)
- New quiz categories
- Various difficulty levels
- Multiple quiz options

Run: python add_questions_enhanced.py
"""

import sqlite3
import sys
from datetime import datetime

DATABASE = "database.db"

# Ensure Windows consoles that default to cp1252 don't crash on emoji output.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# COMPREHENSIVE QUESTIONS WITH CATEGORIES
QUESTIONS = [
    # ==================== PYTHON PROGRAMMING ====================
    {
        "question": "What will this code print? print(8)?",
        "option1": "6",
        "option2": "8",
        "option3": "9",
        "option4": "12",
        "correct_answer": "8",
        "difficulty": "easy",
        "category": "python",
    },
    {
        "question": "In Python, which word is used to start a function?",
        "option1": "function",
        "option2": "def",
        "option3": "func",
        "option4": "make",
        "correct_answer": "def",
        "difficulty": "easy",
        "category": "python",
    },
    {
        "question": "What is a list in Python?",
        "option1": "A single number",
        "option2": "A collection of items in order",
        "option3": "A single word",
        "option4": "A type of error",
        "correct_answer": "A collection of items in order",
        "difficulty": "easy",
        "category": "python",
    },
    {
        "question": "How do you add an item to the end of a list in Python?",
        "option1": "add()",
        "option2": "insert()",
        "option3": "append()",
        "option4": "push()",
        "correct_answer": "append()",
        "difficulty": "medium",
        "category": "python",
    },
    {
        "question": "What does len() do in Python?",
        "option1": "Makes text longer",
        "option2": "Counts items in a list",
        "option3": "Deletes items",
        "option4": "Creates a function",
        "correct_answer": "Counts items in a list",
        "difficulty": "easy",
        "category": "python",
    },
    {
        "question": "What is the correct syntax for a Python dictionary?",
        "option1": "[1, 2, 3]",
        "option2": "(1, 2, 3)",
        "option3": "{key: value}",
        "option4": "<1, 2, 3>",
        "correct_answer": "{key: value}",
        "difficulty": "medium",
        "category": "python",
    },
    {
        "question": "Which method is used to remove an item from a list?",
        "option1": "delete()",
        "option2": "remove()",
        "option3": "pop()",
        "option4": "Both remove() and pop()",
        "correct_answer": "Both remove() and pop()",
        "difficulty": "medium",
        "category": "python",
    },
    {
        "question": "What does the range() function do in Python?",
        "option1": "Creates a list of numbers",
        "option2": "Finds the maximum value",
        "option3": "Sorts a list",
        "option4": "Finds the minimum value",
        "correct_answer": "Creates a list of numbers",
        "difficulty": "medium",
        "category": "python",
    },
    {
        "question": "How do you create a comment in Python?",
        "option1": "// This is a comment",
        "option2": "# This is a comment",
        "option3": "/* This is a comment */",
        "option4": "-- This is a comment",
        "correct_answer": "# This is a comment",
        "difficulty": "easy",
        "category": "python",
    },
    {
        "question": "What is a tuple in Python?",
        "option1": "A changeable collection",
        "option2": "An unchangeable collection",
        "option3": "A type of string",
        "option4": "A function",
        "correct_answer": "An unchangeable collection",
        "difficulty": "medium",
        "category": "python",
    },
    # ==================== GENERAL KNOWLEDGE ====================
    {
        "question": "What is the capital of France?",
        "option1": "London",
        "option2": "Paris",
        "option3": "Berlin",
        "option4": "Madrid",
        "correct_answer": "Paris",
        "difficulty": "easy",
        "category": "general_knowledge",
    },
    {
        "question": "Which planet is known as the Red Planet?",
        "option1": "Venus",
        "option2": "Mars",
        "option3": "Jupiter",
        "option4": "Saturn",
        "correct_answer": "Mars",
        "difficulty": "easy",
        "category": "general_knowledge",
    },
    {
        "question": "Who painted the Mona Lisa?",
        "option1": "Van Gogh",
        "option2": "Picasso",
        "option3": "Leonardo da Vinci",
        "option4": "Michelangelo",
        "correct_answer": "Leonardo da Vinci",
        "difficulty": "medium",
        "category": "general_knowledge",
    },
    {
        "question": "In which year did World War II end?",
        "option1": "1943",
        "option2": "1944",
        "option3": "1945",
        "option4": "1946",
        "correct_answer": "1945",
        "difficulty": "medium",
        "category": "general_knowledge",
    },
    {
        "question": "What is the largest ocean in the world?",
        "option1": "Atlantic Ocean",
        "option2": "Indian Ocean",
        "option3": "Arctic Ocean",
        "option4": "Pacific Ocean",
        "correct_answer": "Pacific Ocean",
        "difficulty": "easy",
        "category": "general_knowledge",
    },
    {
        "question": "Who was the first President of the United States?",
        "option1": "Thomas Jefferson",
        "option2": "Abraham Lincoln",
        "option3": "George Washington",
        "option4": "John Adams",
        "correct_answer": "George Washington",
        "difficulty": "easy",
        "category": "general_knowledge",
    },
    {
        "question": "Which country is home to the Great Wall?",
        "option1": "Japan",
        "option2": "China",
        "option3": "Korea",
        "option4": "Vietnam",
        "correct_answer": "China",
        "difficulty": "easy",
        "category": "general_knowledge",
    },
    # ==================== SCIENCE ====================
    {
        "question": "Which gas do plants need to make food?",
        "option1": "Oxygen",
        "option2": "Carbon Dioxide",
        "option3": "Nitrogen",
        "option4": "Hydrogen",
        "correct_answer": "Carbon Dioxide",
        "difficulty": "easy",
        "category": "science",
    },
    {
        "question": "What is the powerhouse of the cell?",
        "option1": "Nucleus",
        "option2": "Ribosome",
        "option3": "Mitochondria",
        "option4": "Chloroplast",
        "correct_answer": "Mitochondria",
        "difficulty": "medium",
        "category": "science",
    },
    {
        "question": "How many bones are in an adult human body?",
        "option1": "186",
        "option2": "206",
        "option3": "226",
        "option4": "246",
        "correct_answer": "206",
        "difficulty": "medium",
        "category": "science",
    },
    {
        "question": "What does H2O represent?",
        "option1": "Salt",
        "option2": "Water",
        "option3": "Oxygen",
        "option4": "Hydrogen",
        "correct_answer": "Water",
        "difficulty": "easy",
        "category": "science",
    },
    {
        "question": "What is the speed of light?",
        "option1": "100,000 km per second",
        "option2": "200,000 km per second",
        "option3": "300,000 km per second",
        "option4": "400,000 km per second",
        "correct_answer": "300,000 km per second",
        "difficulty": "hard",
        "category": "science",
    },
    {
        "question": "What is the chemical symbol for gold?",
        "option1": "Go",
        "option2": "Gd",
        "option3": "Au",
        "option4": "Ag",
        "correct_answer": "Au",
        "difficulty": "medium",
        "category": "science",
    },
    {
        "question": "Which organ pumps blood in the human body?",
        "option1": "Lungs",
        "option2": "Brain",
        "option3": "Heart",
        "option4": "Liver",
        "correct_answer": "Heart",
        "difficulty": "easy",
        "category": "science",
    },
    # ==================== MATHEMATICS ====================
    {
        "question": "What is 10 plus 5?",
        "option1": "12",
        "option2": "14",
        "option3": "15",
        "option4": "16",
        "correct_answer": "15",
        "difficulty": "easy",
        "category": "mathematics",
    },
    {
        "question": "What is 20 divided by 4?",
        "option1": "4",
        "option2": "5",
        "option3": "6",
        "option4": "7",
        "correct_answer": "5",
        "difficulty": "easy",
        "category": "mathematics",
    },
    {
        "question": "What is 15 percent of 100?",
        "option1": "10",
        "option2": "15",
        "option3": "20",
        "option4": "25",
        "correct_answer": "15",
        "difficulty": "medium",
        "category": "mathematics",
    },
    {
        "question": "If a rectangle has length 5 and width 3, what is its area?",
        "option1": "8",
        "option2": "15",
        "option3": "10",
        "option4": "25",
        "correct_answer": "15",
        "difficulty": "medium",
        "category": "mathematics",
    },
    {
        "question": "What is the square root of 144?",
        "option1": "10",
        "option2": "11",
        "option3": "12",
        "option4": "13",
        "correct_answer": "12",
        "difficulty": "easy",
        "category": "mathematics",
    },
    {
        "question": "What is the value of Pi approximately?",
        "option1": "2.14",
        "option2": "3.14",
        "option3": "4.14",
        "option4": "5.14",
        "correct_answer": "3.14",
        "difficulty": "medium",
        "category": "mathematics",
    },
    {
        "question": "What is 7 times 8?",
        "option1": "54",
        "option2": "56",
        "option3": "58",
        "option4": "60",
        "correct_answer": "56",
        "difficulty": "easy",
        "category": "mathematics",
    },
    # ==================== TECHNOLOGY ====================
    {
        "question": "What does AI stand for?",
        "option1": "Automated Intelligence",
        "option2": "Artificial Intelligence",
        "option3": "Advanced Interaction",
        "option4": "Automated Interaction",
        "correct_answer": "Artificial Intelligence",
        "difficulty": "easy",
        "category": "technology",
    },
    {
        "question": "Which language is used to create web pages?",
        "option1": "Python",
        "option2": "Java",
        "option3": "HTML",
        "option4": "C++",
        "correct_answer": "HTML",
        "difficulty": "medium",
        "category": "technology",
    },
    {
        "question": "What does HTTP stand for?",
        "option1": "HyperText Transfer Protocol",
        "option2": "High Transfer Text Protocol",
        "option3": "Home Text Transfer Protocol",
        "option4": "Hyper Transfer Text Protocol",
        "correct_answer": "HyperText Transfer Protocol",
        "difficulty": "hard",
        "category": "technology",
    },
    {
        "question": "What does GPU stand for?",
        "option1": "Graphics Processor Unit",
        "option2": "General Purpose Unit",
        "option3": "Graphics Processing Unit",
        "option4": "Global Processor Unit",
        "correct_answer": "Graphics Processing Unit",
        "difficulty": "medium",
        "category": "technology",
    },
    {
        "question": "Which company developed JavaScript?",
        "option1": "Microsoft",
        "option2": "Apple",
        "option3": "Netscape",
        "option4": "Google",
        "correct_answer": "Netscape",
        "difficulty": "hard",
        "category": "technology",
    },
    # ==================== SPORTS ====================
    {
        "question": "How many players are on a cricket field?",
        "option1": "9",
        "option2": "10",
        "option3": "11",
        "option4": "12",
        "correct_answer": "11",
        "difficulty": "easy",
        "category": "sports",
    },
    {
        "question": "In tennis, what is the name of the court?",
        "option1": "Field",
        "option2": "Court",
        "option3": "Arena",
        "option4": "Ground",
        "correct_answer": "Court",
        "difficulty": "easy",
        "category": "sports",
    },
    {
        "question": "How many players are on a basketball court per team?",
        "option1": "5",
        "option2": "6",
        "option3": "7",
        "option4": "8",
        "correct_answer": "5",
        "difficulty": "easy",
        "category": "sports",
    },
    {
        "question": "In football, how many players per team are on the field?",
        "option1": "9",
        "option2": "10",
        "option3": "11",
        "option4": "12",
        "correct_answer": "11",
        "difficulty": "medium",
        "category": "sports",
    },
    # ==================== GEOGRAPHY ====================
    {
        "question": "How many continents are there?",
        "option1": "5",
        "option2": "6",
        "option3": "7",
        "option4": "8",
        "correct_answer": "7",
        "difficulty": "easy",
        "category": "geography",
    },
    {
        "question": "What is the smallest country in the world?",
        "option1": "Monaco",
        "option2": "Vatican City",
        "option3": "Liechtenstein",
        "option4": "San Marino",
        "correct_answer": "Vatican City",
        "difficulty": "hard",
        "category": "geography",
    },
    {
        "question": "Which is the largest continent?",
        "option1": "Africa",
        "option2": "North America",
        "option3": "Asia",
        "option4": "Europe",
        "correct_answer": "Asia",
        "difficulty": "medium",
        "category": "geography",
    },
    {
        "question": "What is the capital of India?",
        "option1": "Mumbai",
        "option2": "Delhi",
        "option3": "Bangalore",
        "option4": "Kolkata",
        "correct_answer": "Delhi",
        "difficulty": "easy",
        "category": "geography",
    },
    {
        "question": "Which country has the most population?",
        "option1": "China",
        "option2": "India",
        "option3": "USA",
        "option4": "Indonesia",
        "correct_answer": "India",
        "difficulty": "medium",
        "category": "geography",
    },
    {
        "question": "What is the capital of Japan?",
        "option1": "Osaka",
        "option2": "Kyoto",
        "option3": "Tokyo",
        "option4": "Hiroshima",
        "correct_answer": "Tokyo",
        "difficulty": "easy",
        "category": "geography",
    },
    # ==================== HISTORY ====================
    {
        "question": "In which year did India gain independence?",
        "option1": "1945",
        "option2": "1947",
        "option3": "1949",
        "option4": "1951",
        "correct_answer": "1947",
        "difficulty": "medium",
        "category": "history",
    },
    {
        "question": "Who was the first President of India?",
        "option1": "Jawaharlal Nehru",
        "option2": "Dr. Rajendra Prasad",
        "option3": "Sardar Vallabhbhai Patel",
        "option4": "Mahatma Gandhi",
        "correct_answer": "Dr. Rajendra Prasad",
        "difficulty": "hard",
        "category": "history",
    },
    {
        "question": "In which year did the Titanic sink?",
        "option1": "1910",
        "option2": "1912",
        "option3": "1914",
        "option4": "1916",
        "correct_answer": "1912",
        "difficulty": "medium",
        "category": "history",
    },
    {
        "question": "Who was the first President of the United States?",
        "option1": "Thomas Jefferson",
        "option2": "Abraham Lincoln",
        "option3": "George Washington",
        "option4": "John Adams",
        "correct_answer": "George Washington",
        "difficulty": "easy",
        "category": "history",
    },
    # ==================== LITERATURE ====================
    {
        "question": "Who wrote Romeo and Juliet?",
        "option1": "Jane Austen",
        "option2": "William Shakespeare",
        "option3": "Mark Twain",
        "option4": "Charles Dickens",
        "correct_answer": "William Shakespeare",
        "difficulty": "medium",
        "category": "literature",
    },
    {
        "question": "Who is the author of The Great Gatsby?",
        "option1": "Ernest Hemingway",
        "option2": "F. Scott Fitzgerald",
        "option3": "John Steinbeck",
        "option4": "William Faulkner",
        "correct_answer": "F. Scott Fitzgerald",
        "difficulty": "medium",
        "category": "literature",
    },
    {
        "question": "Who wrote Pride and Prejudice?",
        "option1": "Charlotte Bronte",
        "option2": "Jane Austen",
        "option3": "Emily Dickinson",
        "option4": "Virginia Woolf",
        "correct_answer": "Jane Austen",
        "difficulty": "medium",
        "category": "literature",
    },
    # ==================== BUSINESS & ECONOMICS ====================
    {
        "question": "What is the currency of the United States?",
        "option1": "Pound",
        "option2": "Euro",
        "option3": "Dollar",
        "option4": "Yen",
        "correct_answer": "Dollar",
        "difficulty": "easy",
        "category": "business",
    },
    {
        "question": "What is the stock exchange in India called?",
        "option1": "NASDAQ",
        "option2": "BSE and NSE",
        "option3": "FTSE",
        "option4": "TSX",
        "correct_answer": "BSE and NSE",
        "difficulty": "medium",
        "category": "business",
    },
    {
        "question": "What does GDP stand for?",
        "option1": "Gross Domestic Product",
        "option2": "General Domestic Product",
        "option3": "Gross Development Product",
        "option4": "General Development Product",
        "correct_answer": "Gross Domestic Product",
        "difficulty": "medium",
        "category": "business",
    },
    # ==================== CNACLE / PRACTICE QUESTIONS (No Points) ====================
    {
        "question": "CNACLE: What is 25 plus 17?",
        "option1": "40",
        "option2": "42",
        "option3": "44",
        "option4": "46",
        "correct_answer": "42",
        "difficulty": "easy",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: What is the opposite of cold?",
        "option1": "Warm",
        "option2": "Hot",
        "option3": "Cool",
        "option4": "Freezing",
        "correct_answer": "Hot",
        "difficulty": "easy",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: How many sides does a triangle have?",
        "option1": "2",
        "option2": "3",
        "option3": "4",
        "option4": "5",
        "correct_answer": "3",
        "difficulty": "easy",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: What is the boiling point of water?",
        "option1": "50 degrees Celsius",
        "option2": "75 degrees Celsius",
        "option3": "100 degrees Celsius",
        "option4": "125 degrees Celsius",
        "correct_answer": "100 degrees Celsius",
        "difficulty": "medium",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: In Python, what does the print() function do?",
        "option1": "Creates a new file",
        "option2": "Displays output to console",
        "option3": "Stores data",
        "option4": "Deletes data",
        "correct_answer": "Displays output to console",
        "difficulty": "easy",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: What is the largest mammal in the world?",
        "option1": "Elephant",
        "option2": "Giraffe",
        "option3": "Blue Whale",
        "option4": "Hippopotamus",
        "correct_answer": "Blue Whale",
        "difficulty": "medium",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: How many minutes are in 2 hours?",
        "option1": "60",
        "option2": "90",
        "option3": "120",
        "option4": "180",
        "correct_answer": "120",
        "difficulty": "easy",
        "category": "cnacle_practice",
    },
    {
        "question": "CNACLE: What color do you get by mixing red and blue?",
        "option1": "Green",
        "option2": "Purple",
        "option3": "Orange",
        "option4": "Yellow",
        "correct_answer": "Purple",
        "difficulty": "easy",
        "category": "cnacle_practice",
    },
]


def add_questions():
    """Add enhanced questions to database"""

    print("\n" + "=" * 70)
    print("📚 ADDING ENHANCED QUESTIONS WITH CATEGORIES")
    print("=" * 70)

    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Admin user ID
        admin_id = 1

        added = 0
        skipped = 0

        categories_added = {}

        for q in QUESTIONS:
            try:
                category = q.get("category", "general")
                cursor.execute(
                    """
                INSERT INTO questions
                (question, option1, option2, option3, option4, correct_answer, difficulty, category, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        q["question"],
                        q["option1"],
                        q["option2"],
                        q["option3"],
                        q["option4"],
                        q["correct_answer"],
                        q["difficulty"],
                        category,
                        admin_id,
                        datetime.now().isoformat(),
                    ),
                )
                added += 1
                categories_added[category] = categories_added.get(category, 0) + 1
                print(f"  ✅ Added: {q['question'][:60]}... [{category}]")

            except sqlite3.IntegrityError:
                skipped += 1
            except Exception as e:
                print(f"  ❌ Error: {str(e)}")

        conn.commit()
        conn.close()

        print("\n" + "=" * 70)
        print(f"✅ SUCCESS! Added {added} questions")
        print(f"\n📊 Difficulty Levels:")
        print(f"   Easy: {sum(1 for q in QUESTIONS if q['difficulty'] == 'easy')}")
        print(f"   Medium: {sum(1 for q in QUESTIONS if q['difficulty'] == 'medium')}")
        print(f"   Hard: {sum(1 for q in QUESTIONS if q['difficulty'] == 'hard')}")
        print(f"\n📂 Categories:")
        for cat, count in sorted(categories_added.items()):
            print(f"   {cat.upper()}: {count} questions")
        print("=" * 70 + "\n")

        return True

    except Exception as e:
        print(f"\n❌ ERROR: {e}\n")
        return False


if __name__ == "__main__":
    print("\n🎓 AI QUIZ APP - ADD ENHANCED QUESTIONS WITH CNACLE QUIZ")
    try:
        success = add_questions()
        if success:
            print("✨ Questions added successfully!")
            print("Now run: python app.py\n")
    except Exception as e:
        print(f"❌ Error: {e}\n")
